define({
    option: {
        view: {
            center: [567813.634, 3096556.623],
            zoom: 3,
            resolution: 39091.947994829316

            //maxZoom: 15,
            //minZoom: 6
        }
    },
    extent: [423788.27389814425, 2935769.3486772366, 719810.8880697023, 3188104.0327783935],
    resolutions: [
        156367.79197931726,
        78183.89598965863,
        39091.947994829316,
        19545.973997414658,
        9772.986998707329,
        4886.493499353664,
        2443.246749676832,
        1221.623374838416,
        610.811687419208,
        305.405843709604,
        152.702921854802,
        76.351460927401,
        38.1757304637005,
        19.08786523185025,
        9.543932615925126,
        4.771966307962563,
        2.3859831539812815,
        1.1929915769906407,
        0.5964957884953204,
        0.2982478942476602,
        0.1491239471238301
    ],
    layers: [
        {
            layerType: "GroupLayer",
            name: "XZSJ",
            caption: "现状数据",
            thematicMap: true,
            subLayers: [
                {
                    layerType: "GroupLayer",
                    name: "JCCHSJ",
                    caption: "基础测绘数据",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "KJJZ",
                            caption: "空间基准",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "PMKZD",
                                    caption: "平面控制点",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "PMKZ",
                                            caption: "平面控制",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "KZD",
                                                    caption: "控制点",
                                                    thematicMap: true,
                                                    subLayers: [

                                                    ]
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "KZWGL",
                                                    caption: "控制网线路",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "GCKZD",
                                    caption: "高程控制点",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "GCKZ_2",
                                            caption: "高程控制",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "GCKZ_2_KZD",
                                                    caption: "控制点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "GCKZ_2_KZWGL",
                                                    caption: "控制网线路",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "GCKZ_1",
                                            caption: "高程控制",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "GCKZ_1_KZD",
                                                    caption: "控制点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "GCKZ_1_KZWGL",
                                                    caption: "控制网线路",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "XZJX",
                            caption: "行政界线",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "XZJXXZQH",
                                    caption: "行政区划",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "XZJXXZQH2018",
                                            layerType: "SuperMapWMTSGroupLayer",
                                            caption: "行政区划2018",
                                            layerids: ["GCS330300G1001_JCDL_DS", "GCS330300G1001_JCDL_QX", "GCS330300G1001_JCDL_XZ", "GCS330300G1001_JCDL_XZC"]
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "QYDH",
                            caption: "区域导航",
                            thematicMap: true,
                            subLayers: [

                                {
                                    id: "QYDHQYDH2018",
                                    layerType: "SuperMapWMTSGroupLayer",
                                    caption: "区域导航2018",
                                    layerids: ["GCS330300G1001_QYDH_SJ_2018", "GCS330300G1001_QYDH_QX_2018", "GCS330300G1001_QYDH_XZ_2018", "GCS330300G1001_QYDH_XZC_2018"]
                                }

                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "DXDM",
                            caption: "地形地貌",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "500DLG",
                                    caption: "1:500DLG",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "2000DLG",
                                    caption: "1:2000DLG",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "5000DLG",
                                    caption: "1:5000DLG",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "10000DLG",
                                    caption: "1:10000DLG",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "50000DLG",
                                    caption: "1:50000DLG",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "250000DLG",
                                    caption: "1:250000DLG",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "YGYX",
                            caption: "遥感影像",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "HP",
                                    caption: "航片",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "HPLDWM",
                                            caption: "0.5米",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "HPLDEM",
                                            caption: "0.2米",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "WRJYX",
                                    caption: "无人机影像",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "WRJYXLDEM",
                                            caption: "0.2米",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "GCGFYX",
                                    caption: "国产高分影像",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "GCGFYXEM",
                                            caption: "2米",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "WORLDVIEW",
                                    caption: "WORLDVIEW",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "WORLDVIEWLDWM",
                                            caption: "0.5米",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "QUICKBIRD",
                                    caption: "QUICKBIRD",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "QUICKBIRDLDLYM",
                                            caption: "0.61米",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "IKONOS",
                                    caption: "IKONOS",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "IKONOSYM",
                                            caption: "1米",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "SPOTW",
                                    caption: "SPOT5",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "SPOTWEDWM",
                                            caption: "2.5米",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "WP",
                                    caption: "卫片",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "WPLDWM",
                                            caption: "0.5米",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "DLKJKJ",
                            caption: "地理空间框架",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "SX",
                                    caption: "水系",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "XZ_DLKJKJ_SXD",
                                            layerType: "SuperMapWMTS",
                                            caption: "水系点",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/ff50ad0afc1a1712141806f0c63ab925",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_SXD"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_SWX",
                                            layerType: "SuperMapWMTS",
                                            caption: "水网线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/89d9bf4534e343516cee131563d56339",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_SWX"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_SXFSX",
                                            layerType: "SuperMapWMTS",
                                            caption: "水系附属线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/334c6f069bd98187582ed9f106083ecf",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_SXFSX"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_SXM",
                                            layerType: "SuperMapWMTS",
                                            caption: "水系面",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/656aed30bef8b7028a58286ff18c30c4",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_SXM"
                                        },
                                        {
                                            id: "GCS330300G02_DLSKT_HYD_PY_I",
                                            layerType: "SuperMapWMTS",
                                            caption: "水系实体",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/fc50334cb126c7eac7356ea286a2f1cf?service=wmts&request=GetCapabilities",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_DLSKT_HYD_PY_I"
                                        }

                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "JMD",
                                    caption: "居民地",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "XZ_DLKJKJ_JMDD",
                                            layerType: "SuperMapWMTS",
                                            caption: "居民地点",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/57a62e2577a3538a0069f3a0267ae6a0",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_JMDD"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_JMDX",
                                            layerType: "SuperMapWMTS",
                                            caption: "居民地线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/7b94f7bffef7f121df133ee7e46fc28e",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_JMDX"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_JMDM",
                                            layerType: "SuperMapWMTS",
                                            caption: "居民地面",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/fb002f78fec4cb5842a3ca1dd1c9f2b3",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_JMDM"
                                        },
                                        
                                        {
                                            id: "GCS330300G02_DLSKT_RES_PY_I",
                                            layerType: "SuperMapWMTS",
                                            caption: "居民地实体",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/d3f82e8854375b28c211aadd7f836bcb?service=wmts&request=GetCapabilities",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_DLSKT_RES_PY_I"
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "JT",
                                    caption: "交通",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "XZ_DLKJKJ_JTD",
                                            layerType: "SuperMapWMTS",
                                            caption: "交通点",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0272b4e5f8e22d5807f68713e4253744",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_JTD"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_JTLWX",
                                            layerType: "SuperMapWMTS",
                                            caption: "交通路网线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/72c20e2d664947f84e7e291d489477a5",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_JTLWX"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_JTX",
                                            layerType: "SuperMapWMTS",
                                            caption: "交通线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/90fc330344ebdc1d40d5e5acafda6884",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_JTX"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_TLX",
                                            layerType: "SuperMapWMTS",
                                            caption: "铁路线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/79bd223c8ce89e9514bb8ff291fe1eac",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_TLX"
                                        },
                                        {
                                            id: "GCS330300G02_DLSKT_TRA_LN_I",
                                            layerType: "SuperMapWMTS",
                                            caption: "铁路实体",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0f2ef9878df3d745d7ffc2656f6a83bd?service=wmts&request=GetCapabilities",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_DLSKT_TRA_LN_I"
                                        },
                                        {
                                            id: "GCS330300G02_DLSKT_TRA_PY_I",
                                            layerType: "SuperMapWMTS",
                                            caption: "道路实体",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/452fdf5c4f1c7f59b54812b82354455c?service=wmts&request=GetCapabilities",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_DLSKT_TRA_PY_I"
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "XZJJ",
                                    caption: "行政境界",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "XZ_DLKJKJ_XZQJX",
                                            layerType: "SuperMapWMTS",
                                            caption: "行政区界线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/a0a7d38482dec3715059a01a91bd8231",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_XZQJX"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_XZQY",
                                            layerType: "SuperMapWMTS",
                                            caption: "行政区域",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/fc11e0a8179cf1deb8ff00cf9236e2d2",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_XZQY"
                                        },
                                        {
                                            id: "GCS330300G02_DLSKT_BOU_PY_I",
                                            layerType: "SuperMapWMTS",
                                            caption: "政区实体",
                                            mapUrl:"http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/a833593f0962023e81b998a47c2ac64c?service=wmts&request=GetCapabilities",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_DLSKT_BOU_PY_I"
                                        }

                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "ZB",
                                    caption: "植被",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "XZ_DLKJKJ_ZBM",
                                            layerType: "SuperMapWMTS",
                                            caption: "植被面",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f984049669f27f85576dc4d96baaad061",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_ZBM"
                                        },
                                        {
                                            id: "XZ_DLKJKJ_ZBX",
                                            layerType: "SuperMapWMTS",
                                            caption: "植被线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/09b3c507dfb8bd33c72b6610fbed8f73",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_ZBX"
                                        },
                                        {
                                            id: "GCS330300G02_DLSKT_VEG_PY_I",
                                            layerType: "SuperMapWMTS",
                                            caption: "绿地实体",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/5dc0e580de263a82cef15f2128c8b14d?service=wmts&request=GetCapabilities",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_DLSKT_VEG_PY_I"
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "FZC",
                                    caption: "辅助层",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DLKJKJDMDZ",
                                    caption: "地名地址",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "XZ_DLKJKJ_DMDZ",
                                            layerType: "SuperMapWMTS",
                                            caption: "地名地址",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/5796bb7bc2b3feb48dab6a4f090d425d",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLKJKJ_DMDZ"
                                        },
                                        {
                                            id: "GCS330300G02_GHDLSKT_DMDZ_PT",
                                            layerType: "SuperMapWMTS",
                                            caption: "地名地址点",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2833a170ea41dcf8df1f973f3bc76b86?service=wmts&request=GetCapabilities",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_DMDZ_PT"
                                        },
                                        {
                                            id: "GCS330300G02_GHDLSKT_POI_PT",
                                            layerType: "SuperMapWMTS",
                                            caption: "兴趣点",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/ee5caef9d947ac59bec3b31b7174c407?service=wmts&request=GetCapabilities",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_POI_PT"
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "SWSJ",
                    caption: "三维数据",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "SZGCMX",
                            caption: "数字高程模型",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "EMDEM",
                                    caption: "2米DEM",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "EDWMDEM",
                                    caption: "2.5米DEM",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "WMDEM",
                                    caption: "5米DEM",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YEDWMDEM",
                                    caption: "12.5米DEM",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "EDWWDT",
                            caption: "2.5维地图",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "SWSJSWSJ",
                            caption: "三维实景",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "QXSY",
                                    caption: "倾斜摄影",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "SDMAX",
                                    caption: "3D MAX",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "MAX",
                                    caption: "MAX",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "DXKJSJ",
                    caption: "地下空间数据",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "DXGX",
                            caption: "地下管线",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "XZGXSJPC",
                                    caption: "现状管线数据",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "CQ",
                                            caption: "测区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "XZGXSJPCKZD",
                                            caption: "控制点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "GS",
                                            caption: "给水",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "GSGX",
                                                    caption: "给水管线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "GSGD",
                                                    caption: "给水管点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "PS",
                                            caption: "排水",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "PSYSX",
                                                    caption: "雨水线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "PSYSD",
                                                    caption: "雨水点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "PSWSX",
                                                    caption: "污水线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "PSWSD",
                                                    caption: "污水点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "RQ",
                                            caption: "燃气",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "RQX",
                                                    caption: "燃气线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "RQD",
                                                    caption: "燃气点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DL",
                                            caption: "电力",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "GDX",
                                                    caption: "供电线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "GDD",
                                                    caption: "供电点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "LDX",
                                                    caption: "路灯线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "LDD",
                                                    caption: "路灯点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "XTXHX",
                                                    caption: "交通信号线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "XTXHD",
                                                    caption: "交通信号点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DX",
                                            caption: "电信",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "ZGYDX",
                                                    caption: "中国移动线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "ZGYDD",
                                                    caption: "中国移动点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "ZGDXX",
                                                    caption: "中国电信线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "ZGDXD",
                                                    caption: "中国电信点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "ZGLTX",
                                                    caption: "中国联通线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "ZGLTD",
                                                    caption: "中国联通点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "JCXHX",
                                                    caption: "监控信号线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "JCXHD",
                                                    caption: "监控信号点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "LJX",
                                                    caption: "陆军线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "LJD",
                                                    caption: "陆军点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "HJX",
                                                    caption: "海军线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "HJD",
                                                    caption: "海军点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "GBDS",
                                            caption: "广播电视",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "DSX",
                                                    caption: "电视线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "DSD",
                                                    caption: "电视点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "TX",
                                            caption: "通讯",
                                            thematicMap: true,
                                            subLayers: [
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "ZHGX",
                                                    caption: "综合管线",
                                                    thematicMap: true,
                                                    subLayers: []
                                                },
                                                {
                                                    layerType: "GroupLayer",
                                                    name: "ZHGXD",
                                                    caption: "综合管线点",
                                                    thematicMap: true,
                                                    subLayers: []
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "XZGXSJDTGX",
                                    caption: "现状管线数据",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "SPGXSJ",
                                    caption: "审批管线数据",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHDLSPFA",
                                            caption: "综合道路审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPDL_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合道路-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/43739367cf61658d7e31d2bd73150a67",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPDL_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHDLSP",
                                            caption: "综合道路审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPDL_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合道路-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/e51539987f4077ee0f1d705d1e392361",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPDL_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHGLSPFA",
                                            caption: "综合管廊审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPGL_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合管廊-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0619f6c3151614f5a311a150289517d7",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPGL_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHGLSP",
                                            caption: "综合管廊审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPGL_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合管廊-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/4994ebbbf2e2b087f74d1a7a9de18d84",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPGL_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHGSSPFA",
                                            caption: "综合给水审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPJS_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合给水-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/4a53cfd37cf0da8a24eff818fae5fdaf",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPJS_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHGSSP",
                                            caption: "综合给水审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPJS_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合给水-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/49e6dab0624b833226e6b6ed1eb4dc82",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPJS_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHLDSPFA",
                                            caption: "综合路灯审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPLD_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合路灯-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1934006030628808777f9a1e6a1b8e77",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPLD_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHLDSP",
                                            caption: "综合路灯审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPLD_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合路灯-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/e9ed43600b15d7a679ef72c937a0e38d",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPLD_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHRQSPFA",
                                            caption: "综合燃气审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPRQ_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合燃气-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2bf78b464ed760858859ef7acedc621c",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPRQ_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHRQSP",
                                            caption: "综合燃气审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPRQ_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合燃气-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f1245ac32d190562071444045b83f465",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPRQ_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHSYSPFA",
                                            caption: "综合石油审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPSY_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合石油-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2c926e7dde5121de20260042dbab5879",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPSY_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHSYSP",
                                            caption: "综合石油审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPSY_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合石油-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/27befd6019d0782161ad626a390d1a65",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPSY_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHTXSPFA",
                                            caption: "综合通信审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPTX_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合通信-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9fecd8ef67e6d50a1cd700dc4745aa1d",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPTX_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHTXSP",
                                            caption: "综合通信审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPTX_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合通信-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/4b7397dd62a50fe4c661fbe37d82a853",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPTX_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHWSSPFA",
                                            caption: "综合污水审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPWS_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合污水-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/907753422fee07ec8c66c86e849df493",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPWS_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHWSSP",
                                            caption: "综合污水审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPWS_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合污水-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f23795828c71a63e8e71e6e1e2919800",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPWS_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHYSSPFA",
                                            caption: "综合雨水审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPYS_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合雨水-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/192988aa749744a97d8cc1e668588597",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPYS_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHYSSP",
                                            caption: "综合雨水审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPYS_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合雨水-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/97ff3aae512bc32ce325521303de7aa9",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPYS_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHQTSPFA",
                                            caption: "综合其他审批方案",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPQT_FA_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合其他-审批-方案",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/aab40d9f043c1a5724da3623746f3c2b",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPQT_FA_LN"
                                            }]
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "ZHQTSP",
                                            caption: "综合其他审批",
                                            thematicMap: true,
                                            subLayers: [{
                                                id: "SZGX_SPQT_LN",
                                                layerType: "SuperMapWMTS",
                                                caption: "综合其他-审批",
                                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/fa2604b50c9bef9fce131380de2ceff0",
                                                visible: false,
                                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_SPQT_LN"
                                            }]
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "ZXGXSJ",
                                    caption: "专项管线数据",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "SZGX_ZXDL_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "专项电力",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/018b07c3b7f4cc99b9e8136143717f6b",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_ZXDL_LN"
                                        },
                                        {
                                            id: "SZGX_ZXJS_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "专项给水",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/25a6592fea26948efb5f6c22fc63f66e",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_ZXJS_LN"
                                        },
                                        {
                                            id: "SZGX_ZXQT_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "专项其他",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9bc3294a74eb19c08a2f6aaacc56f4cc",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_ZXQT_LN"
                                        },
                                        {
                                            id: "SZGX_ZXRQ_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "专项燃气",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/10dab480a954b82fadd446ce30925933",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_ZXRQ_LN"
                                        },
                                        {
                                            id: "SZGX_ZXSY_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "专项石油",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9685091bc8a8817dafb9f7e2033aea1c",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_ZXSY_LN"
                                        },
                                        {
                                            id: "SZGX_ZXTX_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "专项通信",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/c0d27b27849586da66a4302fbf5f2829",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_ZXTX_LN"
                                        },
                                        {
                                            id: "SZGX_ZXWS_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "专项污水",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f54875c707ed2ce5ab2db22f27a1480c",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_ZXWS_LN"
                                        },
                                        {
                                            id: "SZGX_ZXYS_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "专项雨水",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/51de9ff2bb80d4ec051b3721b2c52785",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SZGX_ZXWS_LN"
                                        }

                                    ]
                                }
                            ]
                        }
                    ]
                }
                ,
                {
                    layerType: "GroupLayer",
                    name: "DZSJ",
                    caption: "地质数据",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "DZZH",
                            caption: "地质灾害",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300K3005_ZHYHD_YHD_X",
                                    layerType: "SuperMapWMTS",
                                    caption: "隐患点",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8e348d2b4616b12657e6f6115e863bc7",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3005_ZHYHD_YHD_X"
                                },
                                {
                                    id: "GCS330300K3005_ZXQD_ZQD_X",
                                    layerType: "SuperMapWMTS",
                                    caption: "灾情点",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/399595350a390851595b196482da2ba1",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3005_ZXQD_ZQD_X"
                                },
                                {
                                    id: "GCS330300G01_DZYHD_QS_PT",
                                    layerType: "SuperMapWMTS",
                                    caption: "地质隐患点",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/c10bdc9228ae0c7fadd244e44f8f1a9e",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G01_DZYHD_QS_PT"
                                },
                                {
                                    id: "GCS330300G01_FXFFQ_QS_PT",
                                    layerType: "SuperMapWMTS",
                                    caption: "风险防范区点",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8ecbfc7fe052943affc4a3f3ba1f6bc2",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G01_FXFFQ_QS_PT"
                                }

                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "DZYJBHQ",
                            caption: "地质遗迹保护区",
                            thematicMap: true,
                            subLayers: [{
                                id: "GCS330300K3005_DZYJBHQ_DZGY",
                                layerType: "SuperMapWMTS",
                                caption: "地质遗迹保护区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/6b0b3e535a59056676df8942b9fedc21",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3005_DZYJBHQ_DZGY"
                            }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "KSDZHJ",
                            caption: "矿山地质环境",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "DMCJJC",
                            caption: "地面沉降监测",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "DXSJC",
                            caption: "地下水监测",
                            thematicMap: true,
                            subLayers: []
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "DLGQPCSJ",
                    caption: "地理国情普查数据",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "DBFG",
                            caption: "地表覆盖",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "DBXT",
                            caption: "地表形态",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "ZTDXDM",
                                    caption: "总体地形地貌",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "WZSSQCSJCQ",
                            caption: "建成区",
                            thematicMap: true,
                            subLayers: [{
                                id: "YQLL_SQJCQ_2015_PY",
                                layerType: "SuperMapWMTS",
                                caption: "市区建成区2015",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/d2bb7435fe0e3deee59d92a6d49c3877",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:YQLL_SQJCQ_2015_PY"
                            },
                            {
                                id: "YQLL_SQJCQ_2018_PY",
                                layerType: "SuperMapWMTS",
                                caption: "市区建成区2018",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/456ab253de7b980121ca8d3db09d700c",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:YQLL_SQJCQ_2018_PY"
                            },
                            {
                                id: "XZ_DLGQPCSJ_WZSSQCSJCQ_2019",
                                layerType: "SuperMapWMTS",
                                caption: "市区建成区2019",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/d5c98ead9ac4f13263813b2eac8000de",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLGQPCSJ_WZSSQCSJCQ_2019"
                            },
                            {
                                id: "XZ_DLGQPCSJ_WZSSQCSJCQ_2020",
                                layerType: "SuperMapWMTS",
                                caption: "市区建成区2020",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/60358fd3a6aa801e346433d50f89155e",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLGQPCSJ_WZSSQCSJCQ_2020"
                            },
                            {
                                id: "XZ_DLGQPCSJ_WZSSQCSJCQ_TJ_2020",
                                layerType: "SuperMapWMTS",
                                caption: "建成区统计2020",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1e0d360dc5ddfb4fd3d080ed9c438b83",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLGQPCSJ_WZSSQCSJCQ_TJ_2020"
                            }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "WZSQJCQLDLHLHFGL",
                            caption: "温州市区建成区绿地率和绿化覆盖率",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "LDL",
                                    caption: "绿地率",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "XZ_DLGQPCSJ_LDL_2019",
                                        layerType: "SuperMapWMTS",
                                        caption: "绿地率2019",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/997b2dd15add14e6b225057bd9215f57",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLGQPCSJ_LDL_2019"
                                    },
                                    {
                                        id: "XZ_DLGQPCSJ_LDL_2020",
                                        layerType: "SuperMapWMTS",
                                        caption: "绿地率2020",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/71b90529b5fcb34e1b16fe9f604bd693",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLGQPCSJ_LDL_2020"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "LHFGL",
                                    caption: "绿化覆盖率",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "YQLL_SQLDFG_2015_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "市区绿地覆盖_2015",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/6bf20c1f2dc958f83f2763c8c5519853",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:YQLL_SQLDFG_2015_PY"
                                    },
                                    {
                                        id: "YQLL_SQLDFG_2018_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "市区绿地覆盖_2018",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/5680a3e0182f201208f39e60335b9892",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:YQLL_SQLDFG_2018_PY"
                                    },
                                    {
                                        id: "XZ_DLGQPCSJ_LHFGL_2019",
                                        layerType: "SuperMapWMTS",
                                        caption: "市区绿地覆盖_2019",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/aeb95cbaee89db2043123bdeecf1ab9c",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLGQPCSJ_LHFGL_2019"
                                    }, {
                                        id: "XZ_DLGQPCSJ_LHFGL_2020",
                                        layerType: "SuperMapWMTS",
                                        caption: "市区绿地覆盖_2020",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/05159533a02624c13354c68991738708",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_DLGQPCSJ_LHFGL_2020"
                                    },
                                    {
                                        id: "YQLL_SQLDXZ_2015_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "市区绿地现状_2015",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/a37ec42ebb67a9d012aef13e263835e7",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:YQLL_SQLDXZ_2015_PY"
                                    },
                                    {
                                        id: "YQLL_SQLDXZ_2018_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "市区绿地现状_2018",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0a9b2830a46b5c46c02d195a317ef485",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:YQLL_SQLDXZ_2018_PY"
                                    },
                                    {
                                        id: "YQLL_SQLDXZ_2019_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "市区绿地现状_2019",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/dcac92771735627d9d981075434c1752",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:YQLL_SQLDXZ_2019_PY"
                                    }]
                                }
                            ]
                        }
                    ]
                },

                {
                    layerType: "GroupLayer",
                    name: "TDLY",
                    caption: "土地利用现状数据",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "DECQGTDDC",
                            caption: "第二次全国土地调查",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCDJQ",
                                    caption: "地籍区",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCDJZQ",
                                    caption: "地籍子区",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCDLTB",
                                    caption: "地类图斑",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCMZDM",
                                    caption: "面状地貌",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCXZDM",
                                    caption: "线状地貌",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCDZDW",
                                    caption: "点状地物",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCXZDW",
                                    caption: "线状地物",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCDLDWM",
                                    caption: "道路地物面",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCMZFW",
                                    caption: "面状房屋",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCDMZJ",
                                    caption: "地貌注记",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCJFFWZJ",
                                    caption: "街坊房屋注记",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCJFJTZJ",
                                    caption: "街坊交通注记",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCJFQTZJ",
                                    caption: "街坊其他注记",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCJFSXZJ",
                                    caption: "街坊水系注记",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCJFZBZJ",
                                    caption: "街坊植被注记",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCJZD",
                                    caption: "界址点",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCCLKZD",
                                    caption: "测量控制点",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCCLKZDZJ",
                                    caption: "测量控制点注记",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCLHDWM",
                                    caption: "绿化地物面",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCLSD",
                                    caption: "临时点",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCLSM",
                                    caption: "临时面",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCLSX",
                                    caption: "临时线",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCQTDWM",
                                    caption: "其他地物面",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCSTDWM",
                                    caption: "水体地物面",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DECQGTDDCZD",
                                    caption: "宗地",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "DSCQGTDDC",
                            caption: "第三次全国土地调查",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "DSCQGTDDCDWJC",
                                    caption: "定位基础",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "CLKZD",
                                            caption: "测量控制点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "SZZSYXTJZKZD",
                                            caption: "数字正射影像图纠正控制点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "CLKZDZJ",
                                            caption: "测量控制点注记",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DSCQGTDDCJJYZQ",
                                    caption: "境界与政区",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCJJYZQXZQ",
                                            caption: "行政区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCJJYZQXZQJX",
                                            caption: "行政区界线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCJJYZQXZQZJ",
                                            caption: "行政区注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCJJYZQCJDCQ",
                                            caption: "村级调查区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCJJYZQCJDCQJX",
                                            caption: "村级调查区界线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCJJYZQCJDCQZJ",
                                            caption: "村级调查区注记",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DSCQGTDDCDM",
                                    caption: "地貌",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCDMDGX",
                                            caption: "等高线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCDMGCBZD",
                                            caption: "高程注记点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCDMPDT",
                                            caption: "坡度图",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DSCQGTDDCSGSJ",
                                    caption: "栅格数据",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "SGSJSZZSYX",
                                            caption: "数字正射影像",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "SGSJSZGCMX",
                                            caption: "数字高程模型",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DSCQGTDDCTDLY",
                                    caption: "土地利用",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCTDLYDLTB",
                                            caption: "地类图斑",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCTDLYDLTBZJ",
                                            caption: "地类图斑注记",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DSCQGTDDCYJJBNT",
                                    caption: "永久基本农田",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCYJJBNTTB",
                                            caption: "永久基本农田图斑",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCYJJBNTZJ",
                                            caption: "永久基本农田注记",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DSCQGTDDCQTTDYS",
                                    caption: "其他土地要素",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSLSYD",
                                            caption: "临时用地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSLSYDZJ",
                                            caption: "临时用地注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSPZWJSYD",
                                            caption: "批准未建设土地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSPZWJSYDZJ",
                                            caption: "批准未建设土地注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSCZCDYD",
                                            caption: "城镇村等用地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSCZCDYDZJ",
                                            caption: "城镇村等用地注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSGDJB",
                                            caption: "耕地等别",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSGDJBZJ",
                                            caption: "耕地等别注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSZYXMYD",
                                            caption: "重要项目用地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSZYXMYDZJ",
                                            caption: "重要项目用地注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSKFYQ",
                                            caption: "开发园区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSKFYQZJ",
                                            caption: "开发园区注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSGFBQ",
                                            caption: "光伏板区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSGFBQZJ",
                                            caption: "光伏板区注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSTTQ",
                                            caption: "推土区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSTTQZJ",
                                            caption: "推土区注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSCCWJQ",
                                            caption: "拆除未尽区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSCCWJQZJ",
                                            caption: "拆除未尽区注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSLMFW",
                                            caption: "路面范围",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSLMFWZJ",
                                            caption: "路面范围注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSWJMHD",
                                            caption: "无居民海岛",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "DSCQGTDDCQTTDYSWJMHDZJ",
                                            caption: "无居民海岛注记",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DSCQGTDDCDLYS",
                                    caption: "独立要素",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "FJQGH_FJQFW_PY",
                                            layerType: "SuperMapWMTS",
                                            caption: "风景区范围",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/50d15f8c444806019b1afb2ddc47596e",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_FJQFW_PY"
                                        },
                                        {
                                            id: "FJQGH_FJQJX_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "风景区界线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f0baff1bb5ee0bc3e9a1e5413d365c68",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_FJQJX_LN"
                                        },
                                        {
                                            id: "FJQGH_FJQMC_PT",
                                            layerType: "SuperMapWMTS",
                                            caption: "风景区名称",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/e8119b278b8febf20e96a843becff6fb",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_FJQMC_PT"
                                        },
                                        {
                                            id: "FJQGH_HXQFW_PY",
                                            layerType: "SuperMapWMTS",
                                            caption: "核心区面积",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/909e41e76f210e20ea96031004fa0d7a",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_HXQFW_PY"
                                        },
                                        {
                                            id: "FJQGH_JQ_PY",
                                            layerType: "SuperMapWMTS",
                                            caption: "景区",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f788e8df53fe63afd6ccd8dd0ca21393",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_JQ_PY"
                                        },
                                        {
                                            id: "FJQGH_JQJX_LN",
                                            layerType: "SuperMapWMTS",
                                            caption: "景区界线",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8190a9658dba1ee7f24572b41df14e96",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_JQJX_LN"
                                        },
                                        {
                                            id: "FJQGH_JQMC_PT",
                                            layerType: "SuperMapWMTS",
                                            caption: "景区名称",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/42d4d9d71377a6ec2928f80087e4d24c",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_JQMC_PT"
                                        },
                                        {
                                            id: "FJQGH_JQRK_PT",
                                            layerType: "SuperMapWMTS",
                                            caption: "景区入口",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9135ef374893255966d6ad0551ef7dc8",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_JQRK_PT"
                                        },
                                        {
                                            id: "FJQGH_LSWHMC_PT",
                                            layerType: "SuperMapWMTS",
                                            caption: "历史文化名称",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9f5b26a6ca8eae311651575a2d5bdb71",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_LSWHMC_PT"
                                        },
                                        {
                                            id: "FJQGH_WWBHD_PY",
                                            layerType: "SuperMapWMTS",
                                            caption: "文物保护点",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8fdd1a57fba2f549d30cf95e6ab48ccf",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_WWBHD_PY"
                                        },
                                        {
                                            id: "FJQGH_ZGCTCL_PT",
                                            layerType: "SuperMapWMTS",
                                            caption: "中国传统村落",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/cce709e1c26606fb6e5be378781891f9",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:FJQGH_ZGCTCL_PT"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "TDNDBGDC",
                            caption: "土地年度变更调查",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "TDNDBGDCDLTB",
                                    caption: "地类图斑",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "GCS330300G100201_DLTB_2010",
                                            layerType: "SuperMapWMTS",
                                            caption: "地类图斑2010",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/ea5a15373b3ba179f8346eb7a5f481ca",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100201_DLTB_2010"
                                        },
                                        {
                                            id: "GCS330300G100201_DLTB_2014",
                                            layerType: "SuperMapWMTS",
                                            caption: "地类图斑2014",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/b0dd22dc089e188ac6effdb0dd6ee8be",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100201_DLTB_2014"
                                        },
                                        {
                                            id: "GCS330300G100201_DLTB_2015",
                                            layerType: "SuperMapWMTS",
                                            caption: "地类图斑2015",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/99b75144d2aea59fd03e80b9c6841499",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100201_DLTB_2015"
                                        },
                                        {
                                            id: "GCS330300G100201_DLTB_2016",
                                            layerType: "SuperMapWMTS",
                                            caption: "地类图斑2016",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/13a9990cee7e546204c934efbe639927",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100201_DLTB_2016"
                                        },
                                        {
                                            id: "GCS330300G100201_DLTB_2017",
                                            layerType: "SuperMapWMTS",
                                            caption: "地类图斑2017",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f9388beeafd70f2a13cd143424bf911c",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100201_DLTB_2017"
                                        },
                                        {
                                            id: "GCS330300G100201_DLTB_2018",
                                            layerType: "SuperMapWMTS",
                                            caption: "地类图斑2018",
                                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/ba8728a6ae462cd3584ad642795f9c97",
                                            visible: false,
                                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100201_DLTB_2018"
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "TDNDBGDCLXDW",
                                    caption: "零星地物",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G100201_LXDW_2018",
                                        layerType: "SuperMapWMTS",
                                        caption: "零星地物2018",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8a065e2c3133af05b7750d60c395a299",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100201_LXDW_2018"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "TDNDBGDCXZDW",
                                    caption: "线状地物",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G100201_XZDW_2018",
                                        layerType: "SuperMapWMTS",
                                        caption: "线状地物2018",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/3d1ea7f2d67b1ea20d8c20952f673cbf",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100201_XZDW_2018"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "TDNDBGDCDLJX",
                                    caption: "地类界限",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        }

                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "TDZY",
                    caption: "土地资源",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "BZNT",
                            caption: "标准农田",
                            thematicMap: true,
                            subLayers: [{
                                id: "GCS330300G100203_BZNT_2018",
                                layerType: "SuperMapWMTS",
                                caption: "标准农田2018",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/5dcaca30ba446b83fefeaef3b04c40d9",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100203_BZNT_2018"
                            }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "YJBZNT",
                            caption: "永久基本农田",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300G02_YJJBNT_PY",
                                    layerType: "SuperMapWMTS",
                                    caption: "永久基本农田",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/326ddb591ab61af18253b94b321b0603",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_YJJBNT_PY"
                                },
                                {
                                    id: "GCS330300G100202_JBNTBHQ_2017",
                                    layerType: "SuperMapWMTS",
                                    caption: "基本农田保护区2017",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/bab8f8c5e14dd71904623b33ac4eea10",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100202_JBNTBHQ_2017"
                                },
                                {
                                    id: "GCS330300G100202_JBNTBHTB_2017",
                                    layerType: "SuperMapWMTS",
                                    caption: "基本农田保护图斑2017",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/810d83a05570bb6749c77f557b924d19",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100202_JBNTBHTB_2017"
                                },
                                {
                                    id: "GCS330300G100202_JBNTBHPK_2017",
                                    layerType: "SuperMapWMTS",
                                    caption: "基本农田保护片2017",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f43834d5706523faafc5d6289a8e2cdd",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100202_JBNTBHPK_2017"
                                }
                                ,
                                {
                                    id: "GCS330300G100202_JBNTBZP_2017",
                                    layerType: "SuperMapWMTS",
                                    caption: "基本农田标志牌2017",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/df787067d1f09210cdb33da805a27242",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100202_JBNTBZP_2017"
                                },
                                {
                                    id: "GCS330300G100202_JBNTHRHC_2017",
                                    layerType: "SuperMapWMTS",
                                    caption: "基本农田划入划出2017",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/75667fd3c944e45e3043e7ea3e297afa",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100202_JBNTHRHC_2017"
                                }

                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GDHBZY",
                            caption: "耕地后备资源",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GDZLPJ",
                            caption: "耕地质量评价",
                            thematicMap: true,
                            subLayers: [{
                                id: "XZ_TDZY_GDZLPJ_XZQ",
                                layerType: "SuperMapWMTS",
                                caption: "耕地质量评价_行政区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8686a4d663729bb5a7bbddf9470f3ab4",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_XZQ"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_XJFDDY",
                                layerType: "SuperMapWMTS",
                                caption: "县级分等单元",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/67eb7955d8eedd846624dbe724f0b7e6",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_XJFDDY"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_XJLXFDDY",
                                layerType: "SuperMapWMTS",
                                caption: "县级零星分等单元",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/c2af13b0dff5f27c021012a0c9e1f8ec",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_XJLXFDDY"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_ZBQ",
                                layerType: "SuperMapWMTS",
                                caption: "分等因素指标区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/161914cfadbcee2db6d452ccda308828",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_ZBQ"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_GZZDFB",
                                layerType: "SuperMapWMTS",
                                caption: "耕作制度分布区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/b9482ae081f0f1ebefbcb4b735769e9d",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_GZZDFB"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_LYXS",
                                layerType: "SuperMapWMTS",
                                caption: "利用系数分布区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1a2d6fb48590f33b4e085c7380a6d5ca",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_LYXS"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_JJXS",
                                layerType: "SuperMapWMTS",
                                caption: "土地经济系数等值区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/5b7adf8cb2736df3d1714a74e45c0b80",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_JJXS"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_TRFL",
                                layerType: "SuperMapWMTS",
                                caption: "土壤肥力分布区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/a5e3703becba957c24d6f5c96808a8f2",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_TRFL"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_BCTRZD",
                                layerType: "SuperMapWMTS",
                                caption: "表层土壤质地分布区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/6beadc09f2930f41c6c28c0bd9bdaec1",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_BCTRZD"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_TRYJZHL",
                                layerType: "SuperMapWMTS",
                                caption: "土壤有机质含量分布区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/24139c3835b2948d02c06f7604427759",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_TRYJZHL"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_ZACJDBSD",
                                layerType: "SuperMapWMTS",
                                caption: "障碍层距地表深度分布区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2d1778736e54733bb29a50626e1d94e1",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_ZACJDBSD"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_GGBZL",
                                layerType: "SuperMapWMTS",
                                caption: "灌溉保证率分布区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/282ef404ad446ed9c25422516bfd2336",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_GGBZL"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_PSTJ",
                                layerType: "SuperMapWMTS",
                                caption: "排水条件分布区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/36610cd0b9eca112c6288f4f92148559",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_PSTJ"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_HBGD",
                                layerType: "SuperMapWMTS",
                                caption: "海拔高度分布区",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/b896857bcb03e2340b1ccce5ea36fc79",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_HBGD"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_BZYD",
                                layerType: "SuperMapWMTS",
                                caption: "标准样地",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/714f9a2b5b1b897653d4b6e8c5f5edbe",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_BZYD"
                            }, {
                                id: "XZ_TDZY_GDZLPJ_XZDW",
                                layerType: "SuperMapWMTS",
                                caption: "耕地质量评价_线状地物",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/b1b81062cecff2361f80158a449c2c7b",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_TDZY_GDZLPJ_XZDW"
                            }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "BCGD",
                            caption: "补充耕地",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZDQPZHDJ",
                            caption: "征地区片综合地价",
                            thematicMap: true,
                            subLayers: [{
                                id: "ZDQPZHDJ",
                                layerType: "SuperMapWMTSGroupLayer",
                                caption: "征地区片综合地价",
                                layerids: ["GCS330300G01_TDZY_ZDQPZHDJ_CJ_PY", "GCS330300G01_TDZY_ZDQPZHDJ_XJ_PY"]
                            }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GYUDDC",
                            caption: "工业用地调查",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "KFQTDJYLY",
                            caption: "开发区土地集约利用",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "NCCLJSYDDC",
                            caption: "农村存量建设用地调查",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "TDZYDXYDZXDC",
                            caption: "低效用地专项调查",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "DXYDDCQ",
                                    caption: "低效用地调查区",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G100209_DCQTB_2018",
                                        layerType: "SuperMapWMTS",
                                        caption: "低效调查区图斑2018",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/94ff6bedbe9b1ccf30ba2dc1e6b0d1d9",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100209_DCQTB_2018"
                                    },
                                    {
                                        id: "GCS330300G100209_DCQTB_2020",
                                        layerType: "SuperMapWMTS",
                                        caption: "低效调查区图斑2020",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1cd99f5adbb70b58ee334cc084da1673",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100209_DCQTB_2020"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DXYDDCDY",
                                    caption: "低效用地调查单元",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G100209_DCDYTB_2018",
                                        layerType: "SuperMapWMTS",
                                        caption: "低效调查单元图斑2018",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1d342ae5cc5e750e68d0ac894df8bb8c",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100209_DCDYTB_2018"
                                    },
                                    {
                                        id: "GCS330300G100209_DCDYTB_2020",
                                        layerType: "SuperMapWMTS",
                                        caption: "低效调查单元图斑2020",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/d57613a53b8c1d2abc3b172b90bad437",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100209_DCDYTB_2020"
                                    }]
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "TDZYDXYDZKF",
                            caption: "低效用地再开发",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300K3003_DXYDZKF_ZKFXMHX",
                                    layerType: "SuperMapWMTS",
                                    caption: "城镇低效用地再开发项目",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/e6e14757ff9f1324ae5afca30a377abf",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_DXYDZKF_ZKFXMHX"
                                }
                            ]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "SLZY",
                    caption: "森林资源",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "SHIJGYL",
                            caption: "市级公益林",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GYLC",
                            caption: "国有林场",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZRBHQ",
                            caption: "自然保护地",
                            thematicMap: true,
                            subLayers: [{
                                id: "ZRBHD_WZSXZ",
                                layerType: "SuperMapWMTS",
                                caption: "现状",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/67e14d9e4aad9444229bc5a834425b8b",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:ZRBHD_WZSXZ"
                            },
                            {
                                id: "ZRBHD_WZSYHH",
                                layerType: "SuperMapWMTS",
                                caption: "优化后",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8579d9e7d2842bbcdb8777ebfd7b87bb",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:ZRBHD_WZSYHH"
                            }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "SENGJGYL",
                            caption: "省级公益林",
                            thematicMap: true,
                            subLayers: [{
                                id: "XZ_SLZY_GYL_SHENG",
                                layerType: "SuperMapWMTS",
                                caption: "省级公益林",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/ec9b4f33da92c022d7cd915546d4002b",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:XZ_SLZY_GYL_SHENG"
                            }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GSMM",
                            caption: "古树名木",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GJLYHCYJLYYHSWYFZJYJCSJ",
                            caption: "国家林业和草原局林业有害生物要防治检疫监测数据",
                            thematicMap: true,
                            subLayers: []
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "KCZL",
                    caption: "矿产资源",
                    thematicMap: true,
                    subLayers: [

                        {
                            layerType: "GroupLayer",
                            name: "TKQWF",
                            caption: "探矿权范围",
                            thematicMap: true,
                            subLayers: [{
                                id: "GCS330300G100301_TKQFW_2016",
                                layerType: "SuperMapWMTS",
                                caption: "探矿权范围2016",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/10a11ae20946d916815bb5f9c7d2aba",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100301_TKQFW_2016"
                            }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "CKQFW",
                            caption: "采矿权范围",
                            thematicMap: true,
                            subLayers: [{
                                id: "GCS330300G100302_CKQFW_2016",
                                layerType: "SuperMapWMTS",
                                caption: "采矿权范围2016",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/bba134790757f3bb62d2349f188c3af7",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G100302_CKQFW_2016"
                            }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "KSDZ",
                            caption: "矿山地址",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "BBFW",
                            caption: "报部范围",
                            thematicMap: true,
                            subLayers: []
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "SDZY",
                    caption: "湿地资源",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "ZDSDML",
                            caption: "重点湿地名录",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "SDZYDC",
                            caption: "湿地资源调查",
                            thematicMap: true,
                            subLayers: [{
                                id: "SDZYDC_WZSDCL_20_2015",
                                layerType: "SuperMapWMTS",
                                caption: "湿地存量_20度带_2015",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2b3be3c00fafebdce14dd7145f977d43",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SDZYDC_WZSDCL_20_2015"
                            },
                            {
                                id: "SDZYDC_WZSDCL_20_2016",
                                layerType: "SuperMapWMTS",
                                caption: "湿地存量_20度带_2016",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0e8c9929dbce9d4695c351dc7549011b",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SDZYDC_WZSDCL_20_2016"
                            },
                            {
                                id: "SDZYDC_WZSDCL_20_2017",
                                layerType: "SuperMapWMTS",
                                caption: "湿地存量_20度带_2017",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2fb08f82ce4a4b98c5dfc0d15f41f536",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SDZYDC_WZSDCL_20_2017"
                            },
                            {
                                id: "SDZYDC_WZSDCL_20_2018",
                                layerType: "SuperMapWMTS",
                                caption: "湿地存量_20度带_2018",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/c936c121ee4b41fb64fda2f9740de48b",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SDZYDC_WZSDCL_20_2018"
                            },
                            {
                                id: "SDZYDC_WZSDCL_21_2015",
                                layerType: "SuperMapWMTS",
                                caption: "湿地存量_21度带_2015",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/aa8c4b4ce6adacea17ae6999fdcc04ec",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SDZYDC_WZSDCL_21_2015"
                            },
                            {
                                id: "SDZYDC_WZSDCL_21_2016",
                                layerType: "SuperMapWMTS",
                                caption: "湿地存量_21度带_2016",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/a5eae0076984e8195bcd11f1f1083dad",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SDZYDC_WZSDCL_21_2016"
                            },
                            {
                                id: "SDZYDC_WZSDCL_21_2017",
                                layerType: "SuperMapWMTS",
                                caption: "湿地存量_21度带_2017",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/4eeded6d014ac1789b8a00c5d31a0e2e",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SDZYDC_WZSDCL_21_2017"
                            },
                            {
                                id: "SDZYDC_WZSDCL_21_2018",
                                layerType: "SuperMapWMTS",
                                caption: "湿地存量_21度带_2018",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8158ba3544da4c64f554758a0a2da3c7",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SDZYDC_WZSDCL_21_2018"
                            }]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "HYZY",
                    caption: "海洋资源",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "WJMHDDC",
                            caption: "无居民海岛调查",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "WTHXZDC",
                            caption: "围填海现状调查",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "HYJZJ",
                            caption: "海域基准价",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "HYFDDJ",
                            caption: "海域分等定级",
                            thematicMap: true,
                            subLayers: []
                        }
                    ]
                }

            ]
        },
        {
            layerType: "GroupLayer",
            name: "GHSJ",
            caption: "规划数据",
            thematicMap: true,
            subLayers: [
                {
                    layerType: "GroupLayer",
                    name: "YBMGH",
                    caption: "原部门规划",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "ZTGNQGH",
                            caption: "主体功能区规划",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "YBMGHTDLYZTGH",
                            caption: "土地利用总体规划",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHTDLYZTGHTDGHDL",
                                    caption: "土地规划地类",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200201_TDGHDL_2011",
                                        layerType: "SuperMapWMTS",
                                        caption: "土地规划地类2011",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2ad9591e84eabb464d2838d214b440ad",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_TDGHDL_2011"
                                    },
                                    {
                                        id: "GCS330300G200201_TDGHDL_2012",
                                        layerType: "SuperMapWMTS",
                                        caption: "土地规划地类2012",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/86ac52a5170fee4c8e2922eb24c1a2b3",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_TDGHDL_2012"
                                    },
                                    {
                                        id: "GCS330300G200201_TDGHDL_2013",
                                        layerType: "SuperMapWMTS",
                                        caption: "土地规划地类2013",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/16e93c32eb83b156c311c9e3c90e9417",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_TDGHDL_2013"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHTDLYZTGHJSYDGZQ",
                                    caption: "建设用地管制区",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200201_JSYDGZQ_2011",
                                        layerType: "SuperMapWMTS",
                                        caption: "建设用地管制区2011",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/7c6de7fdf074b90151850719a294ded1",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JSYDGZQ_2011"
                                    },
                                    {
                                        id: "GCS330300G200201_JSYDGZQ_2012",
                                        layerType: "SuperMapWMTS",
                                        caption: "建设用地管制区2012",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0fe160d626f1489fe1462ad22bdc06ef",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JSYDGZQ_2012"
                                    },
                                    {
                                        id: "GCS330300G200201_JSYDGZQ_2013",
                                        layerType: "SuperMapWMTS",
                                        caption: "建设用地管制区2013",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1be8d1c098ef26735e530db1d9dc2351",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JSYDGZQ_2013"
                                    },
                                    {
                                        id: "GCS330300G200201_JSYDGZQ_2016",
                                        layerType: "SuperMapWMTS",
                                        caption: "建设用地管制区2016",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/95a6a70664e6ae4a2476133e2793aa37",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JSYDGZQ_2016"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHTDLYZTGHJSYDGZBJ",
                                    caption: "建设用地管制边界",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200201_JSYDGZBJ_2011",
                                        layerType: "SuperMapWMTS",
                                        caption: "建设用地管制边界2011",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/779265e13df6416099dbb396194f3236",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JSYDGZBJ_2011"
                                    },
                                    {
                                        id: "GCS330300G200201_JSYDGZBJ_2012",
                                        layerType: "SuperMapWMTS",
                                        caption: "建设用地管制边界2012",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/192c6fa337a634bbf6caaee667d96910",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JSYDGZBJ_2012"
                                    },
                                    {
                                        id: "GCS330300G200201_JSYDGZBJ_2013",
                                        layerType: "SuperMapWMTS",
                                        caption: "建设用地管制边界2013",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9eb07ed570a4899daa9bb5694d815a91",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JSYDGZBJ_2013"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHTDLYZTGHJQDLTB",
                                    caption: "基期地类图斑",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200201_JQDLTB_2011",
                                        layerType: "SuperMapWMTS",
                                        caption: "基期地类图斑2011",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/aa951a2161088a39999343da52f2bf9e",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JQDLTB_2011"
                                    },
                                    {
                                        id: "GCS330300G200201_JQDLTB_2012",
                                        layerType: "SuperMapWMTS",
                                        caption: "基期地类图斑2012",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/6b8e9a2068626eb0a17df067a44b8de1",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JQDLTB_2012"
                                    },
                                    {
                                        id: "GCS330300G200201_JQDLTB_2013",
                                        layerType: "SuperMapWMTS",
                                        caption: "基期地类图斑2013",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/b60eae287145775f13e292220fa5a7cf",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_JQDLTB_2013"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHTDLYZTGHTDLYGHYT",
                                    caption: "规划用途",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200201_GHYT_2011",
                                        layerType: "SuperMapWMTS",
                                        caption: "规划用途2011",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/b3ec19449ed1285ca5c5769bda705dc3",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_GHYT_2011"
                                    },
                                    {
                                        id: "GCS330300G200201_GHYT_2012",
                                        layerType: "SuperMapWMTS",
                                        caption: "规划用途2012",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/81910711e47265723c515974974cdf83",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_GHYT_2012"
                                    },
                                    {
                                        id: "GCS330300G200201_GHYT_2013",
                                        layerType: "SuperMapWMTS",
                                        caption: "规划用途2013",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9b27567b67ab87f316423df86996e798",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_GHYT_2013"
                                    },
                                    {
                                        id: "GCS330300G200201_GHYT_2016",
                                        layerType: "SuperMapWMTS",
                                        caption: "规划用途2016",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/63e8264b33662dbb54ef02c12b64457a",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_GHYT_2016"
                                    },
                                    {
                                        id: "GCS330300G200201_GHYT_2018",
                                        layerType: "SuperMapWMTS",
                                        caption: "规划用途2018",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/916925464ed3d7920cf7dffcaa0ad5d4",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200201_GHYT_2018"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHTDLYZTGHTDLYZTGHJTZ",
                                    caption: "土地利用总体规划局部调整",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300K3003_GHJT_GHJBTZ_X",
                                        layerType: "SuperMapWMTS",
                                        caption: "规划局部调整",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0f8d011a46f54dc64211c04304235040",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_GHJT_GHJBTZ_X"
                                    }]
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "YBMGHZTGH",
                            caption: "总体规划",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZTGHGGPTSS",
                                    caption: "公共配套设施",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZTGHYD",
                                    caption: "用地",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200701_GHYD_2017",
                                        layerType: "SuperMapWMTS",
                                        caption: "规划用地2017",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8e6a2224b623ac594f86f5f923f0a083",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200701_GHYD_2017"
                                    }, {
                                        id: "BZY_YDGH_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "用地规划",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2a8fb4ce13b1a12032a23dbd71f39415",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BZY_YDGH_PY"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHKZXXXGHSX",
                                    caption: "四线",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200701_LX_2017",
                                        layerType: "SuperMapWMTS",
                                        caption: "蓝线2017",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8e1f0d5c1ded1ae9214bdb300c18ce60",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200701_LX_2017"
                                    },
                                    {
                                        id: "GCS330300G200701_LVX_2017",
                                        layerType: "SuperMapWMTS",
                                        caption: "绿线2017",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9948569074908d6f4ce43fa0bdba16b0",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200701_LVX_2017"
                                    },
                                    {
                                        id: "GCS330300G200701_HX_2017",
                                        layerType: "SuperMapWMTS",
                                        caption: "黄线2017",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0c80cbe4d4813d7eafdcb6685943d4ff",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200701_HX_2017"
                                    },
                                    {
                                        id: "GCS330300G200701_STKZX_2017",
                                        layerType: "SuperMapWMTS",
                                        caption: "生态控制线2017",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/19590d2c1635156f3e340a819a74d52b",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200701_STKZX_2017"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZTGHSZ",
                                    caption: "市政",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHYBMGHDLJT",
                                    caption: "道路",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZTGHDLJT",
                                    caption: "交通",
                                    thematicMap: true,
                                    subLayers: []
                                }

                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "YBMGHFQGH",
                            caption: "分区规划",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "YBMGHKZXXXGH",
                            caption: "控制性详细规划",
                            thematicMap: true,
                            subLayers: [

                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHKZXXXGHYD",
                                    caption: "用地",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "KZXXXGHYD",
                                            layerType: "SuperMapWMTSGroupLayer",
                                            caption: "规划用地",
                                            layerids: ["BKY_DKBH_AP", "BKY_DKFH_PT", "BKY_GHDY_PY", "BKY_GHJF_PY", "BKY_GHPQ_PY", "BKY_XMFW_PY", "BKY_YDGH_PY"]
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHKZXXXGHSX",
                                    caption: "四线",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "BKK_LHLX_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "绿化绿线",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/00cdd6421279455806f358ac7e4708ff",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKK_LHLX_PY"
                                    },
                                    {
                                        id: "JCSSHX",
                                        layerType: "SuperMapWMTSGroupLayer",
                                        caption: "基础设施黄线",
                                        layerids: ["BKK_SSHX_LN", "BKK_SSHX_PY"]
                                    },
                                    {
                                        id: "BKK_SXLX_LN",
                                        layerType: "SuperMapWMTS",
                                        caption: "水系蓝线",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/3d5d6b8a14c009dff94c9d57b6a946a9",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKK_SXLX_LN"
                                    },
                                    {
                                        id: "BKK_WBZX_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "文保紫线",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/4b4caff79f366f861a04daf7fca23686",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKK_WBZX_PY"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHKZXXXGHJT",
                                    caption: "交通",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "BKJ_DLBX_LN",
                                        layerType: "SuperMapWMTS",
                                        caption: "道路边线",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/627b4693b11b562450a6cdd3c54325a3",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKJ_DLBX_LN"
                                    },
                                    {
                                        id: "DLZXX",
                                        layerType: "SuperMapWMTSGroupLayer",
                                        caption: "道路中心线",
                                        layerids: ["BKJ_DLMC_AP", "BKJ_DLZX_LN"]
                                    }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHKZXXXGHKZX",
                                    caption: "控制线",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHKZXXXGHGGPTSS",
                                    caption: "公共配套设施",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            id: "GGPTSS",
                                            layerType: "SuperMapWMTSGroupLayer",
                                            caption: "公共配套设施",
                                            layerids: ["BKP_GPFH_PT", "BKP_GPSS_PT", "BKP_GPSS_PY"]
                                        }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHKZXXXGHDK",
                                    caption: "地块",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHKZXXXGHKZXXXGHJBTZ",
                                    caption: "控制性详细规划局部调整",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "YBMGHZXGH",
                            caption: "专项规划",
                            thematicMap: true,
                            subLayers: [

                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXGHDZZHFZGF",
                                    caption: "地质灾害防治规划",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXGHWZSKCZYGF",
                                    caption: "温州市矿产资源规划",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXGHWZSSQCZGHQKCZYDCBG",
                                    caption: "温州市三区城镇规划区矿产资源调查报告",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXKCZYKTGHQK",
                                    caption: "矿产资源勘查规划区块",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200303_KANCHQK_2016",
                                        layerType: "SuperMapWMTS",
                                        caption: "矿产资源勘查规划区块2016",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/c4a513cbc56fda2fa32195fe4c379696",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200303_KANCHQK_2016"
                                    }]
                                }, {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXKCZYKCGHQK",
                                    caption: "矿产资源开采规划区块",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200303_KAICQK_2016",
                                        layerType: "SuperMapWMTS",
                                        caption: "矿产资源开采规划区块2016",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/73e0cd7af30542922bd16cdbae9f5573",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200303_KAICQK_2016"
                                    }]
                                }, {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXKCZYKCGHQK",
                                    caption: "矿产资源开采规划区块",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G200303_KSZLXMDZ_2016",
                                        layerType: "SuperMapWMTS",
                                        caption: "矿山地质环境治理恢复重点项目2016",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/c5659789de97355a555dc8b386d74776",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200303_KSZLXMDZ_2016"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXGHSSWLYGH",
                                    caption: "十四五林业规划",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXGHWDZZGF",
                                    caption: "土地整治规划",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXGHZRHBDGF",
                                    caption: "自然保护地规划",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXGHLDLYBHGF",
                                    caption: "林地利用保护规划",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXGHYD",
                                    caption: "用地",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "YBMGHZXGHZX",
                                    caption: "专项规划线",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "BKK_ZXHX_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "黄线",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/d860a3c9258ca199321041acdcd6f241",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKK_ZXHX_PY"
                                    },
                                    {
                                        id: "BKK_ZXLX_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "绿线",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2412355533eddd8cb243cd257e36d3b8",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKK_ZXLX_PY"
                                    },
                                    {
                                        id: "BKK_ZXZX_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "紫线",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/824eaeca9986a0aa12337ec2bc370d0c",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKK_ZXZX_PY"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "LSWHMC",
                                    caption: "历史文化名城",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "BLS_LSCQFW",
                                        layerType: "SuperMapWMTS",
                                        caption: "历史城区范围",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f5383c881156efc209fe35af4511e0c8",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BLS_LSCQFW"
                                    },
                                    {
                                        id: "BLS_LSJZ",
                                        layerType: "SuperMapWMTS",
                                        caption: "历史建筑",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/e48944f9677e8dde32aba5b74e1331fc",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BLS_LSJZ"
                                    },
                                    {
                                        id: "BLS_NTJLSJZ",
                                        layerType: "SuperMapWMTS",
                                        caption: "拟推荐历史建筑",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/032656da0642e4e4bb35e589f06b7195",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BLS_NTJLSJZ"
                                    },
                                    {
                                        id: "BLS_WBDW",
                                        layerType: "SuperMapWMTS",
                                        caption: "文保单位",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/65d1f2fc3f2ec3b5fa9495dbb2c5d4d6",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BLS_WBDW"
                                    }]
                                }
                            ]
                        }

                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "SPJ",
                    caption: "双评价",
                    thematicMap: true,
                    subLayers: [
                        {
                            id: "GCS330300G02_STBHZYX_PY",
                            layerType: "SuperMapWMTS",
                            caption: "生态保护重要性",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/ca5ce841025ff981985537208308c9cc",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_STBHZYX_PY"
                        },
                        {
                            id: "GCS330300G02_NYSCSYX_PY",
                            layerType: "SuperMapWMTS",
                            caption: "农业生产适宜性",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/6f5f2d92f9120abb38cb81f4103e1182",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_NYSCSYX_PY"
                        },
                        {
                            id: "GCS330300G02_CZJSSYX_PY",
                            layerType: "SuperMapWMTS",
                            caption: "城镇建设适宜性",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1544ced177353533e2cffc01fa2b0c7a",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_CZJSSYX_PY"
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "ZYKZX",
                    caption: "重要控制线",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "ZYKZXSTBHHX",
                            caption: "生态保护红线",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300G200106_STBHHX_2018",
                                    layerType: "SuperMapWMTS",
                                    caption: "生态保护红线2018",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1e0d981c3d00ac1d772fb0f7f9bfb5aa",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200106_STBHHX_2018"
                                },
                                {
                                    id: "GCS330300G02_STBHHX_LD_PY",
                                    layerType: "SuperMapWMTS",
                                    caption: "陆地",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/e668f60483308041f37a029289e661d7",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_STBHHX_LD_PY"
                                },
                                {
                                    id: "GCS330300G02_STBHHX_HY_PY",
                                    layerType: "SuperMapWMTS",
                                    caption: "海洋",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/078fe9cf66a749e5187d6e0438f0d501",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_STBHHX_HY_PY"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZYKZXYJJBNTBHHX",
                            caption: "永久基本农田保护红线",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300G200105_YJJBNTHX_2017",
                                    layerType: "SuperMapWMTS",
                                    caption: "永久基本农田保护红线2017",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/430ec023420bfee354740107ae723103",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200105_YJJBNTHX_2017"
                                },
                                {
                                    id: "GCS330300G200105_YJJBNTHX_2020",
                                    layerType: "SuperMapWMTS",
                                    caption: "永久基本农田保护红线2020",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/11914526e12b612b9369205d89da64d2",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200105_YJJBNTHX_2020"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZYKZXCZKFBJ",
                            caption: "城镇开发边界",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300G200101_CZKFBJ_2017",
                                    layerType: "SuperMapWMTS",
                                    caption: "城镇开发边界2017",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/6f313aed13e93a7c671b89b163637146",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G200101_CZKFBJ_2017"
                                },
                                {
                                    id: "GCS330300G02_CZKFBJ_PY",
                                    layerType: "SuperMapWMTS",
                                    caption: "城镇开发边界",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/baf7aee862dbe48e8dbcfb27e90a0ce6",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_CZKFBJ_PY"
                                }
                            ]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "SQGK",
                    caption: "三区管控",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "SQGKSTKJ",
                            caption: "生态空间",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "SQGKCZKJ",
                            caption: "城镇空间",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "SQGKNYKJ",
                            caption: "农业空间",
                            thematicMap: true,
                            subLayers: []
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "ZLGH",
                    caption: "战略规划",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "ZLGHQYZL",
                            caption: "区域战略",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZLGHHYFZZL",
                            caption: "行业发展战略",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZLGHZCQGH",
                            caption: "中长期规划",
                            thematicMap: true,
                            subLayers: []
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "ZTGH",
                    caption: "总体规划",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "ZTGHSJGTKJGH",
                            caption: "市级国土空间规划",
                            thematicMap: true,
                            subLayers: [{
                                id: "GCS330300G02_GYQKX_SQ_PY",
                                layerType: "SuperMapWMTS",
                                caption: "工业用地区块线",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/175aaf014cd6d7dac3562630cf355dfe",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GYQKX_SQ_PY"
                            }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZTGHXJGTKJZTGH",
                            caption: "县级国土空间总体规划",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZTGHXZJGTKJZTGH",
                            caption: "乡镇级国土空间总体规划",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZTGHCZGH",
                            caption: "村庄规划",
                            thematicMap: true,
                            subLayers: []
                        }
                    ]
                }
            ]
        },
        {
            layerType: "GroupLayer",
            name: "GLSJ",
            caption: "管理数据",
            thematicMap: true,
            subLayers: [
                {
                    layerType: "GroupLayer",
                    name: "GLSJTDGY",
                    caption: "自然资源开发利用",
                    thematicMap: true,
                    subLayers: [
                        {
                            id: "GCS330300G02_GHDLSKT_TDGY_PY",
                            layerType: "SuperMapWMTS",
                            caption: "土地供应",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/17f56da38a2dbc0bc257075b8c8c20e1?service=wmts&request=GetCapabilities",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_TDGY_PY"
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "GLSJQQDJ",
                    caption: "确权登记",
                    thematicMap: true,
                    subLayers: [
                        {
                            id: "GCS330300G02_GHDLSKT_ZD_PY",
                            layerType: "SuperMapWMTS",
                            caption: "宗地/海",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/c5c1aee3ed9bc4e33620f7d81b500298?service=wmts&request=GetCapabilities",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_ZD_PY"
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "DBCGL",
                    caption: "不动产管理",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "ZRZYQQDJ",
                            caption: "自然资源确权登记",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "FWDJ",
                                    caption: "房地登记",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJJZDZJ",
                                            caption: "界址点注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJJZXZJ",
                                            caption: "界址线注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJJZX",
                                            caption: "界址线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJYCZRZ",
                                            caption: "预测自然幢",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJZRZ",
                                            caption: "自然幢",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJZD",
                                            caption: "宗地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDZDZW",
                                            caption: "点状定着物",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJXZDZW",
                                            caption: "线状定着物",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJMZDZW",
                                            caption: "面状定着物",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJZDZJ",
                                            caption: "宗地注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJGZW",
                                            caption: "构筑物",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJCMJZD",
                                            caption: "超面积宗地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDSJZD",
                                            caption: "地上界址点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDSJZX",
                                            caption: "地上界址线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDSZDZJ",
                                            caption: "地上宗地注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJHSZD",
                                            caption: "地上宗地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDXJZD",
                                            caption: "地下界址点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDXJZX",
                                            caption: "地下界址线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDXZDJ",
                                            caption: "地下宗地注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDXZD",
                                            caption: "地下宗地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJSYQJZDZJ",
                                            caption: "所有权界址点注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJSYQJZD",
                                            caption: "所有权界址点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJSYQJZXZJ",
                                            caption: "所有权界址线注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJSYQJZX",
                                            caption: "所有权界址线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJSYQZDZJ",
                                            caption: "所有权宗地注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJSYQZD",
                                            caption: "所有权宗地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJXZYSZJ",
                                            caption: "行政要素注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJXZQJX",
                                            caption: "行政区界线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJXZQ",
                                            caption: "行政区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJHKSZZSYX",
                                            caption: "航空数字正射影像",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJSZSGDT",
                                            caption: "数字栅格地图",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJJCDLZJ",
                                            caption: "基础地理注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJSCD",
                                            caption: "实测点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJTYGLC",
                                            caption: "图宇管理层",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJFHT",
                                            caption: "分户图",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJMJJST",
                                            caption: "面积计算图",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJLPT",
                                            caption: "楼盘层",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJXTDBLCXM",
                                            caption: "XT_大比例尺项目",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJZDTC",
                                            caption: "宗地图层",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJFHTCZT",
                                            caption: "分户图层_ZT",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJFHTCTK",
                                            caption: "分户图层_TK",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDWD",
                                            caption: "地物点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDMD",
                                            caption: "地貌点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDWX",
                                            caption: "地物线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDMX",
                                            caption: "地貌线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDMM",
                                            caption: "地貌面",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJFWDWM",
                                            caption: "房屋地物面",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJGHHX",
                                            caption: "规划红线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJDGXZJ",
                                            caption: "等高线注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJGCDZJ",
                                            caption: "高程点注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJKZD",
                                            caption: "控制点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "FWDJKZDZJ",
                                            caption: "控制点注记",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "SLDJ",
                                    caption: "森林登记",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "SLDJZD",
                                            caption: "宗地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "SLDJSYQZD",
                                            caption: "所有权宗地",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "SLDJTDSYQ",
                                            caption: "土地所有权",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "SLDJLQ",
                                            caption: "林权",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "SLDJCBJYQ",
                                            caption: "承包经营权",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "HYDJ",
                                    caption: "海域登记",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "HYDJZHJZDZJ",
                                            caption: "宗海界址点注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "HYDJZHJZD",
                                            caption: "宗海界址点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "HYDJZHJZXZJ",
                                            caption: "宗海界址线注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "HYDJZHJZX",
                                            caption: "宗海界址线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "HYDJZHZJ",
                                            caption: "宗海注记",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "HYDJZH",
                                            caption: "宗海",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "NJQ",
                                    caption: "农经权",
                                    thematicMap: true,
                                    subLayers: [
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQCJQY",
                                            caption: "村级区域",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQDK",
                                            caption: "地块",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQDZDW",
                                            caption: "点状地物",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQJBNTBHQ",
                                            caption: "基本农田保护区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQJZD",
                                            caption: "界址点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQJZX",
                                            caption: "界址线",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQKZD",
                                            caption: "控制点",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQMZDW",
                                            caption: "面状地物",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQQYJX",
                                            caption: "区域界限",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQXJQY",
                                            caption: "乡级区域",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQXJXZQ",
                                            caption: "县级行政区",
                                            thematicMap: true,
                                            subLayers: []
                                        },
                                        {
                                            layerType: "GroupLayer",
                                            name: "NJQXZDW",
                                            caption: "线状地物",
                                            thematicMap: true,
                                            subLayers: []
                                        }
                                    ]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "DA",
                                    caption: "档案",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "KCGL",
                    caption: "矿产管理",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "TKQ",
                            caption: "探矿权",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300K3004_TKQ_KCDJ",
                                    layerType: "SuperMapWMTS",
                                    caption: "探矿权登记",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/522ee5554e610a471454bf579649ff34",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_TKQ_KCDJ"
                                },
                                {
                                    id: "GCS330300K3004_TKQ_KCDJ_LS",
                                    layerType: "SuperMapWMTS",
                                    caption: "探矿权登记_历史",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/44a062cd0a2e2fc4984b7289b4cad196",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_TKQ_KCDJ_LS"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "CKQ",
                            caption: "采矿权",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300K3004_CKQ_CKQDJ",
                                    layerType: "SuperMapWMTS",
                                    caption: "采矿权登记",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/686b866f593cd4cdb232fd7a3e1f429d",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_CKQ_CKQDJ"
                                },
                                {
                                    id: "GCS330300K3004_CKQ_CKQDJ_LS",
                                    layerType: "SuperMapWMTS",
                                    caption: "采矿权登记—历史",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/a9d7dcb70a033d21157ef60b72d4909d",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_CKQ_CKQDJ_LS"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "CLDJ",
                            caption: "储量登记",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300K3004_CLDJ_CLDJ",
                                    layerType: "SuperMapWMTS",
                                    caption: "残留登记",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/466aedcc3c09c0ca93c3c4bf89f745b2",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_CLDJ_CLDJ"
                                },
                                {
                                    id: "GCS330300K3004_CLDJ_CMDJ",
                                    layerType: "SuperMapWMTS",
                                    caption: "查明登记",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1ac2f1c3d74c1eaaca30f2a661a07d39",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_CLDJ_CMDJ"
                                },
                                {
                                    id: "GCS330300K3004_CLDJ_DRKQSDJ",
                                    layerType: "SuperMapWMTS",
                                    caption: "地热矿泉水登记",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/e784ecfdf695bf06df1232b7b8a30a9c",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_CLDJ_DRKQSDJ"
                                },
                                {
                                    id: "GCS330300K3004_CLDJ_YFDJ",
                                    layerType: "SuperMapWMTS",
                                    caption: "压覆登记",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/836dbdd0dddcc6946a7843a23fe72aba",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_CLDJ_YFDJ"
                                },
                                {
                                    id: "GCS330300K3004_CLDJ_ZYDJ",
                                    layerType: "SuperMapWMTS",
                                    caption: "占用登记",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2a58aeba312fa1869d262d8d887a0410",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_CLDJ_ZYDJ"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "LSKS",
                            caption: "绿色矿山",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300K3004_LSKS_LSKS",
                                    layerType: "SuperMapWMTS",
                                    caption: "绿色矿山",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/fb30dfcd6fcdc00165ab092aa450d26a",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_LSKS_LSKS"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "FQKS",
                            caption: "废弃矿山",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300K3004_FQKS_FQKS",
                                    layerType: "SuperMapWMTS",
                                    caption: "废弃矿山",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/22204ced8be5353c71751fc8517ffdc4",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3004_FQKS_FQKS"
                                }
                            ]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "ZRZYKFLY",
                    caption: "自然资源开发利用",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "ZRZYKFLYTDGY",
                            caption: "土地供应",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "GDHX",
                                    caption: "供地红线",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "GTKJYTGZ",
                    caption: "国土空间用途管制",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZJSGLXM",
                            caption: "建设管理项目",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330000K3003_JSYDYS_YSDK_X",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地预审",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/bd4f973591113c503812be1f04aa649b",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330000K3003_JSYDYS_YSDK_X"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZTDCB",
                            caption: "土地储备",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "TDCBNSCDK",
                                    caption: "拟收储地块",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "TDCBYSCDK",
                                    caption: "已收储地块",
                                    thematicMap: true,
                                    subLayers: [{
                                        id: "GCS330300G03_TDCB_CBDK_PY",
                                        layerType: "SuperMapWMTS",
                                        caption: "在储备地块",
                                        mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f6a9d02896f38e9cdd65696eab6a0f28",
                                        visible: false,
                                        queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G03_TDCB_CBDK_PY"
                                    }]
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "TDCBYDJZDJT",
                                    caption: "用地基准地价图",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZTDZS",
                            caption: "土地征收",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "TDZSZDBCHX",
                                    caption: "征地补偿红线",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZNZYBP",
                            caption: "农转用报批",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330000k3003_JSYDBP_NZYDK_X",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地报批",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/4141970fadd76d4415e6e4ef2b6a74f4",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330000k3003_JSYDBP_NZYDK_X"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZGDHX",
                            caption: "供地红线",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300K3003_TDGY_GDDK_LS",
                                    layerType: "SuperMapWMTS",
                                    caption: "供地地块—历史",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/131604fc93ca037a91129c8a748d2935",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDGY_GDDK_LS"
                                },
                                {
                                    id: "GCS330300K3003_TDGY_GDDK_X",
                                    layerType: "SuperMapWMTS",
                                    caption: "供地地块",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/89b37a01aa4ddf699eb0d7d07ea9ddc7",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDGY_GDDK_X"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZYDYSHXZXZYJS",
                            caption: "用地预审和选址意见书",
                            thematicMap: true,
                            subLayers: [

                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZGHTJ",
                            caption: "规划条件",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZJSYDGHXKS",
                            caption: "建设用地规划许可证",
                            thematicMap: true,
                            subLayers: [

                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZJSGCGHXKZJSFASCHSGTSC",
                            caption: "建设工程规划许可证、建设方案审查和施工图审查",
                            thematicMap: true,
                            subLayers: [


                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZFYX",
                            caption: "放验线",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZGHHS",
                            caption: "规划核实",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZYDFHYS",
                            caption: "用地复核验收",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZBZD",
                            caption: "标准地",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZSSNYDBA",
                            caption: "设施农用地备案",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZLSYD",
                            caption: "临时用地",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GTKJYTGZGHGL",
                            caption: "规划管理",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "GHGLZDJSXMGHXZ",
                                    caption: "重大建设项目规划选址",
                                    thematicMap: true,
                                    subLayers: []
                                },
                                {
                                    layerType: "GroupLayer",
                                    name: "GHGLKGTXTZ",
                                    caption: "控规弹性通则",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        }

                    ]
                },

                {
                    layerType: "GroupLayer",
                    name: "GTSTXF",
                    caption: "国土空间生态修复",
                    thematicMap: true,
                    subLayers: [{
                        layerType: "GroupLayer",
                        name: "GTSTXFTDZZ",
                        caption: "土地整治",
                        thematicMap: true,
                        subLayers: [
                            {
                                id: "GCS330300K3003_TDZZ_GBZJS_LX_X",
                                layerType: "SuperMapWMTS",
                                caption: "高标准建设地块-立项",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1e1a2927a999c1cf4c4daf417b799803",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_GBZJS_LX_X"
                            },
                            {
                                id: "GCS330300K3003_TDZZ_GBZJS_YS_X",
                                layerType: "SuperMapWMTS",
                                caption: "高标准建设地块-验收",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/003b5c044b650094fdae2e8577797f0e",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_GBZJS_YS_X"
                            },
                            {
                                id: "GCS330300K3003_TDZZ_GBZTS_LX_X",
                                layerType: "SuperMapWMTS",
                                caption: "高标准提升地块-立项",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/152eebe7ea12441ad48085872874c322",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_GBZTS_LX_X"
                            },
                            {
                                id: "GCS330300K3003_TDZZ_GBZTS_YS_X",
                                layerType: "SuperMapWMTS",
                                caption: "高标准提升地块-验收",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9412a78ab26122c8e827d0af9b062022",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_GBZTS_YS_X"
                            },
                            {
                                id: "GCS330300K3003_TDZZ_JSYDFK_LX_",
                                layerType: "SuperMapWMTS",
                                caption: "建设用地复垦地块-立项",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1101f991c85bf9f59b181566b4979e5c",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_JSYDFK_LX_"
                            },
                            {
                                id: "GCS330300K3003_TDZZ_JSYDFK_YS_",
                                layerType: "SuperMapWMTS",
                                caption: "建设用地复垦地块-验收",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8c977f15598201c16ea7cd7a6be6c9d6",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_JSYDFK_YS_"
                            },
                            {
                                id: "GCS330300K3003_TDZZ_HGSDK_LX_X",
                                layerType: "SuperMapWMTS",
                                caption: "旱改水地块-立项",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f5ea4c70fa4a50dd7fb17bdcc2f9ac7b",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_HGSDK_LX_X"
                            },
                            {
                                id: "GCS330300K3003_TDZZ_HGSDK_YS_X",
                                layerType: "SuperMapWMTS",
                                caption: "旱改水地块-验收",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/4b0fc568846c44c57bb355b69fe123ac",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_HGSDK_YS_X"
                            },
                            {
                                id: "GCS330300K3003_TDZZ_KZGD_LX_X",
                                layerType: "SuperMapWMTS",
                                caption: "垦造耕地-立项",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/84b575b10258dfbd2ed04b7b1bc245bb",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_KZGD_LX_X"
                            },
                            {
                                id: "GCS330300K3003_TDZZ_KZGD_YS_X",
                                layerType: "SuperMapWMTS",
                                caption: "垦造耕地-验收",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/881beb22b93ddbe3508bd66060788e93",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_TDZZ_KZGD_YS_X"
                            }
                        ]
                    }, {
                        layerType: "GroupLayer",
                        name: "GTSTXFZJGG",
                        caption: "增减挂钩",
                        thematicMap: true,
                        subLayers: [
                            {
                                id: "JX_DK",
                                layerType: "SuperMapWMTS",
                                caption: "建新地块",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/b3ae711cc151b51f54e0446c53c8ee8e",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:JX_DK"
                            },
                            {
                                id: "LX_CJ_DK",
                                layerType: "SuperMapWMTS",
                                caption: "立项拆旧复垦地块",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/3e873f0edef576208f5f44f39732412a",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:LX_CJ_DK"
                            },
                            {
                                id: "YSH_CJDK_LYQK",
                                layerType: "SuperMapWMTS",
                                caption: "验收后拆旧地块利用情况",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/691813200c0573602749ab068e2c6b41",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:YSH_CJDK_LYQK"
                            },
                            {
                                id: "YS_CJ_DK",
                                layerType: "SuperMapWMTS",
                                caption: "验收拆旧复垦地块",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/684869772675e0b59fbdfa8ba940f3c7",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:YS_CJ_DK"
                            }
                        ]
                    },
                    {
                        layerType: "GroupLayer",
                        name: "GTSTXFZJGG",
                        caption: "农村土地综合整治",
                        thematicMap: true,
                        subLayers: [
                            {
                                id: "GCS330300K3003_NCTDZHZZ_CJDK_L",
                                layerType: "SuperMapWMTS",
                                caption: "拆旧地块",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0fea61ca0a9ddf205fdf2901e67316e5",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_NCTDZHZZ_CJDK_L"
                            },
                            {
                                id: "GCS330300K3003_NCTDZHZZ_JXDK_X",
                                layerType: "SuperMapWMTS",
                                caption: "建新地块",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2855ce2c1d8a68f9c760c18610cecebd",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3003_NCTDZHZZ_JXDK_X"
                            }

                        ]
                    }]
                },
                {
                    layerType: "GroupLayer",
                    name: "PHJG",
                    caption: "批后监管",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "WTZZ",
                            caption: "问题整治",
                            thematicMap: true,
                            subLayers: [
                                {
                                    id: "GCS330300K3099_WTZZ_DPFWTZZ",
                                    layerType: "SuperMapWMTS",
                                    caption: "大棚房问题整治",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/83506815a95f5b420dfbd2ab7be9d019",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3099_WTZZ_DPFWTZZ"
                                },
                                {
                                    id: "GCS330300K3099_WTZZ_SSNYDZZX",
                                    layerType: "SuperMapWMTS",
                                    caption: "设施农用地整治",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/dc09a863e0fa1221cb4a75026c02f33b",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300K3099_WTZZ_SSNYDZZX"
                                }
                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GEWY",
                            caption: "供而未用",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "PEWG",
                            caption: "批而未供",
                            thematicMap: true,
                            subLayers: [
								{
                                    id: "gcs330300g1_phjg_pewg_qs_py",
                                    layerType: "SuperMapWMTS",
                                    caption: "批而未供全市",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2e3c56027cc8d5222e39d9e9bcb7b3e7",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:gcs330300g1_phjg_pewg_qs_py"
                                },
                                {
                                    id: "gcs330301g1_phjg_pewg_py",
                                    layerType: "SuperMapWMTS",
                                    caption: "批而未供",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f4ebffba9f9ad6fad4129142dc84b72b",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:gcs330301g1_phjg_pewg_py"
                                }

                            ]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "XZTD",
                            caption: "闲置土地",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "YEWJ",
                            caption: "用而未尽",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "YPYY",
                            caption: "已批已用",
                            thematicMap: true,
                            subLayers: [{
                                    id: "gcs330300g1_phjg_ypyy_qs_py",
                                    layerType: "SuperMapWMTS",
                                    caption: "已批已用全市",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/3de590cf7758d3e2f412aa4e06e27d85",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:gcs330300g1_phjg_ypyy_qs_py"
                                },
                                {
                                    id: "gcs330301g1_phjg_ypyy_py",
                                    layerType: "SuperMapWMTS",
                                    caption: "已批已用",
                                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/5e2eb981f3cb6d46da98cd961d20cbd8",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:gcs330301g1_phjg_ypyy_py"
                                }]
                        },
                        {
                            layerType: "GroupLayer",
                            name: "WPJCTBWFTB",
                            caption: "卫片监测图斑、违法图斑",
                            thematicMap: true,
                            subLayers: [{
                                id: "GL_PHJG_WPJCWFTB",
                                layerType: "SuperMapWMTS",
                                caption: "卫片监测图斑、违法图斑",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/3ac54fa012c04a5df35aa64a50564f89",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GL_PHJG_WPJCWFTB"
                            }]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "ZHGL",
                    caption: "综合管理",
                    thematicMap: true,
                    subLayers: [

                        {
                            layerType: "GroupLayer",
                            name: "CHDLXXJG",
                            caption: "测绘地理信息监管",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZFJC",
                            caption: "执法监察",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "ZFJD",
                            caption: "执法监管",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "HYGL",
                            caption: "行业管理",
                            thematicMap: true,
                            subLayers: [
                                {
                                    layerType: "GroupLayer",
                                    name: "CHDLHYGL",
                                    caption: "测绘地理行业管理",
                                    thematicMap: true,
                                    subLayers: []
                                }
                            ]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
                    name: "GHSPL",
                    caption: "规划审批类",
                    thematicMap: true,
                    subLayers: [
                        {
                            id: "GCS330300G02_GHDLSKT_JGCH_PY",
                            layerType: "SuperMapWMTS",
                            caption: "竣工核实",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/8513e03d5e35da5a2982a5833f29b6b1?service=wmts&request=GetCapabilities",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_JGCH_PY"
                        },
                        {
                            id: "GCS330300G02_GHDLSKT_JSYD_PY",
                            layerType: "SuperMapWMTS",
                            caption: "用地审批",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/1f33ece96ef2f486e09051a5495b190e?service=wmts&request=GetCapabilities",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_JSYD_PY"
                        },
                         

                        {
                        layerType: "GroupLayer",
                        name: "DJSJ",
                        caption: "地籍数据",
                        thematicMap: true,
                        subLayers: [{
                            id: "SSD_DJSJ_PY",
                            layerType: "SuperMapWMTS",
                            caption: "面状地籍数据",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/5e47ad086415fdf292190cb25829ad8a",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SSD_DJSJ_PY"
                        },
                        {
                            id: "GCS330300G02_GHDLSKT_DJQ_PY",
                            layerType: "SuperMapWMTS",
                            caption: "地籍区",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/91b6cfb9bbe8d61e2c66a8c3fc71d22c?service=wmts&request=GetCapabilities",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_DJQ_PY"
                        },
                        {
                            id: "GCS330300G02_GHDLSKT_DJZQ_PY",
                            layerType: "SuperMapWMTS",
                            caption: "地籍子区",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9d9f373df1a2bc4d446e2e6aefb3472a?service=wmts&request=GetCapabilities",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_DJZQ_PY"
                        }]
                    },
                   
                    {
                        layerType: "GroupLayer",
                        name: "HXSJ",
                        caption: "红线数据",
                        thematicMap: true,
                        subLayers: [
                            {
                                id: "SSH_HXSJ_PY",
                                layerType: "SuperMapWMTS",
                                caption: "面状红线数据",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/a018ae3495f857481c0820640eb8f71e",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SSH_HXSJ_PY"
                            },
                            {
                                id: "GCS330300G02_GHDLSKT_XZHX_PY",
                                layerType: "SuperMapWMTS",
                                caption: "规划选址",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/c7ebec76a2d1a3965f3090a541389d1f?service=wmts&request=GetCapabilities",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_XZHX_PY"
                            }]
                    },
                   
                    {
                        layerType: "GroupLayer",
                        name: "ZPFW",
                        caption: "工程审批",
                        thematicMap: true,
                        subLayers: [{
                            id: "GCS330300G02_GHDLSKT_ZPFW_PY",
                            layerType: "SuperMapWMTS",
                            caption: "总平范围",
                            mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/4f5569854a32bc13b9eec925cd06ccae?service=wmts&request=GetCapabilities",
                            visible: false,
                            queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G02_GHDLSKT_ZPFW_PY"
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GYQYZPT",
                            caption: "工业企业总平图",
                            thematicMap: true,
                            subLayers: [{
                                id: "SSG_GHZYD_PY",
                                layerType: "SuperMapWMTS",
                                caption: "规划总用地",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/836b1bba8d186b2948f066b7e8262f59",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SSG_GHZYD_PY"
                            }, {
                                id: "SSG_JZJD_PY",
                                layerType: "SuperMapWMTS",
                                caption: "建筑基底",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/4b5f7e52951284b24626fdaffdfc5be5",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SSG_JZJD_PY"
                            }, {
                                id: "SSG_ZJD_AP",
                                layerType: "SuperMapWMTS",
                                caption: "注记点",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/62542df89026414493fb5d84175e43b9",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SSG_ZJD_AP"
                            }, {
                                id: "SSG_ZJX_LN",
                                layerType: "SuperMapWMTS",
                                caption: "注记线",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/30936d44775a1aca2b3310a3ac35ee96",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SSG_ZJX_LN"
                            }]
                        },

                        {
                            layerType: "GroupLayer",
                            name: "JZGJZPT",
                            caption: "居住公建总平图",
                            thematicMap: true,
                            subLayers: [{
                                id: "SSJ_GHZYD_PY",
                                layerType: "SuperMapWMTS",
                                caption: "规划总用地",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/45de913e1ac081cd671687589db6617c",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SSJ_GHZYD_PY"
                            },
                            {
                                id: "SSJ_JZJD_PY",
                                layerType: "SuperMapWMTS",
                                caption: "建筑基底",
                                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/9931e152a05dcf6c5933b3beb48eb608",
                                visible: false,
                                queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:SSJ_JZJD_PY"
                            }]
                        }

                    ]
                    }]
                },
                {
                    layerType: "GroupLayer",
                    name: "STK",
                    caption: "实体库",
                    thematicMap: true,
                    subLayers: [
                        {
                            layerType: "GroupLayer",
                            name: "DLSTK",
                            caption: "地理实体库",
                            thematicMap: true,
                            subLayers: []
                        },
                        {
                            layerType: "GroupLayer",
                            name: "GHSTK",
                            caption: "规划地理实体库",
                            thematicMap: true,
                            subLayers: []
                        }
                    ]
                }
            ]
        },
        {
            layerType: "GroupLayer",
            name: "KZXXXGHYD",
            caption: "控制性详细规划用地",
            subLayers: [

                {
                    id: "BKY_DKBH_AP",
                    layerType: "SuperMapWMTS",
                    caption: "地块编号",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/446b2608271c159fb6ab1d4fb324303e",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKY_DKBH_AP"
                },
                {
                    id: "BKY_DKFH_PT",
                    layerType: "SuperMapWMTS",
                    caption: "地块符号",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/2cc4d8e67b2221781a353d54ae140596",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKY_DKFH_PT"
                },
                {
                    id: "BKY_GHDY_PY",
                    layerType: "SuperMapWMTS",
                    caption: "规划单元",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/dcfac953e5495e1e3dcd3e56edfb5716",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKY_GHDY_PY"
                },
                {
                    id: "BKY_GHJF_PY",
                    layerType: "SuperMapWMTS",
                    caption: "规划街坊",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/eca7f66dc0a9fd2a84385cb8024e1507",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKY_GHJF_PY"
                },
                {
                    id: "BKY_GHPQ_PY",
                    layerType: "SuperMapWMTS",
                    caption: "规划片区",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/b261dc45b3a9e121e608c4da5628364c",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKY_GHPQ_PY"
                },
                {
                    id: "BKY_XMFW_PY",
                    layerType: "SuperMapWMTS",
                    caption: "项目范围",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/03013899be28922ded05071ed3a1a8d3",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKY_XMFW_PY"
                },
                {
                    id: "BKY_YDGH_PY",
                    layerType: "SuperMapWMTS",
                    caption: "用地规划",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/a7bfb09131c3ccf9c097cb3ce75411ac",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKY_YDGH_PY"
                }

            ]
        },
        {
            layerType: "GroupLayer",
            name: "KZXXGHJCSSHX",
            caption: "基础设施黄线",
            subLayers: [

                {
                    id: "BKK_SSHX_LN",
                    layerType: "SuperMapWMTS",
                    caption: "基础设施黄线",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/f2371fa1f1b6726b7c441650364c20ed",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKK_SSHX_LN"
                },
                {
                    id: "BKK_SSHX_PY",
                    layerType: "SuperMapWMTS",
                    caption: "基础设施黄线面",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/52c4b2e92f8f90f517c98bbf69d0bdf0",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKK_SSHX_PY"
                }

            ]
        },
        {
            layerType: "GroupLayer",
            name: "KZXXGHGGPTSS",
            caption: "公共配套设施",
            subLayers: [


                {
                    id: "BKP_GPFH_PT",
                    layerType: "SuperMapWMTS",
                    caption: "公共配套设施符号",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/41af324dc08050b64399604dc763743e",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKP_GPFH_PT"
                },
                {
                    id: "BKP_GPSS_PT",
                    layerType: "SuperMapWMTS",
                    caption: "公共配套设施点",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/3bfbd4ca9ff48a463711eba89448041d",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKP_GPSS_PT"
                },
                {
                    id: "BKP_GPSS_PY",
                    layerType: "SuperMapWMTS",
                    caption: "公共配套设施面",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/6dd18b8d49df247a46ace449c305521c",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKP_GPSS_PY"
                }

            ]
        },
        {
            layerType: "GroupLayer",
            name: "KZXXGHDLZXX",
            caption: "道路中心线",
            subLayers: [

                {
                    id: "BKJ_DLMC_AP",
                    layerType: "SuperMapWMTS",
                    caption: "道路名称",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0e42964b0fbcda09ec5c42dd479ea506",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKJ_DLMC_AP"
                },
                {
                    id: "BKJ_DLZX_LN",
                    layerType: "SuperMapWMTS",
                    caption: "道路中心线",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/c87b775f5a1760190d118c6fc756ef2d",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:BKJ_DLZX_LN"
                }

            ]
        },
        {
            layerType: "GroupLayer",
            name: "XZQH2018",
            caption: "行政区划2018",
            subLayers: [

                {
                    id: "GCS330300G1001_JCDL_DS",
                    layerType: "SuperMapWMTS",
                    caption: "地市2018",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/66fab1dfb73bf01f8daf7097ebb3436f",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G1001_JCDL_DS"
                },
                {
                    id: "GCS330300G1001_JCDL_QX",
                    layerType: "SuperMapWMTS",
                    caption: "区县2018",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/ec6690c754ea63ceadf3d27b09810126",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G1001_JCDL_QX"
                },
                {
                    id: "GCS330300G1001_JCDL_XZ",
                    layerType: "SuperMapWMTS",
                    caption: "乡镇2018",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/a63be02c765afdd56b680c9be5d61bff",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G1001_JCDL_XZ"
                },
                {
                    id: "GCS330300G1001_JCDL_XZC",
                    layerType: "SuperMapWMTS",
                    caption: "行政村2018",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/21cee94ccda3bcaac685222aab172618",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G1001_JCDL_XZC"
                }

            ]
        },
        {
            layerType: "GroupLayer",
            name: "QYDH2018",
            caption: "区域导航2018",
            subLayers: [

                {
                    id: "GCS330300G1001_QYDH_SJ_2018",
                    layerType: "SuperMapWMTS",
                    caption: "市级2018",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/88165a2553f25e9e40fb0995b61ae5a4",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G1001_QYDH_SJ_2018"
                },
                {
                    id: "GCS330300G1001_QYDH_QX_2018",
                    layerType: "SuperMapWMTS",
                    caption: "区县2018",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/ab37077da2e68d46ae7e322b960df89b",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G1001_QYDH_QX_2018"
                },
                {
                    id: "GCS330300G1001_QYDH_XZ_2018",
                    layerType: "SuperMapWMTS",
                    caption: "乡镇2018",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/072b9208a63084ec21b133dfa1f2ca3f",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G1001_QYDH_XZ_2018"
                },
                {
                    id: "GCS330300G1001_QYDH_XZC_2018",
                    layerType: "SuperMapWMTS",
                    caption: "行政村2018",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/0ac21f6563122aa1193150cc9a358dcb",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G1001_QYDH_XZC_2018"
                }

            ]
        },
        {
            layerType: "GroupLayer",
            name: "ZDZHQPJ",
            caption: "征地区片综合地价",
            subLayers: [

                {
                    id: "GCS330300G01_TDZY_ZDQPZHDJ_CJ_PY",
                    layerType: "SuperMapWMTS",
                    caption: "征地区片综合地价_村界",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/449fac384b001abe47f2492c5d205c58",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G01_TDZY_ZDQPZHDJ_CJ_PY"
                },
                {
                    id: "GCS330300G01_TDZY_ZDQPZHDJ_XJ_PY",
                    layerType: "SuperMapWMTS",
                    caption: "征地区片综合地价_区县界",
                    mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/b9bb6cfba6db56a2058389cda5060c4e",
                    visible: false,
                    queryUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wfs/aacf3da749d744eeb323d29021d9dd67?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=wz_data_cgcs2000_4549:GCS330300G01_TDZY_ZDQPZHDJ_XJ_PY"
                }

            ]
        }
    ]
});
