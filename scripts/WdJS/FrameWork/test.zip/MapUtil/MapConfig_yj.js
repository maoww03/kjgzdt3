define({
    code:"1",
    option: {
        view: {
            center: [567813.634, 3096556.623],
            zoom: 3
            //maxZoom: 15,
            //minZoom: 6
        }
    },
    extent: [423788.27389814425, 2935769.3486772366, 719810.8880697023, 3188104.032778393],
    resolutions: [  
        156367.79197931726,
        78183.89598965863,
        39091.947994829316,
        19545.973997414658,
        9772.986998707329,
        4886.493499353664,
        2443.246749676832,
        1221.623374838416,
        610.811687419208,
        305.405843709604,
        152.702921854802,
        76.351460927401,
        38.1757304637005,
        19.08786523185025,
        9.543932615925126,
        4.771966307962563,
        2.3859831539812815,
        1.1929915769906407,
        0.5964957884953204,
        0.2982478942476602,
        0.1491239471238301
    ],
    layers: [
        {
            layerType: "GroupLayer",
            name: "XZSJ",
            caption: "现状数据",
            thematicMap: true,
            subLayers:[
				{
					layerType: "GroupLayer",
					name: "TDZY",
					caption: "土地资源",
					thematicMap: true,
					subLayers: [
						{
							layerType: "GroupLayer",
							name: "TDZYDXYDZXDC",
							caption: "低效用地专项调查",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300g100209_dcqtb_2019_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "低效调查区图斑2019_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330324_1002_CZDXYDZXDC_DXYDDCQ_2019/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300g100209_dcqtb_2019_latest_1_0"
                                },
                                {
                                    id: "gcs330300g100209_dcqtb_2020_1_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "低效调查区图斑2020_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330324_1002_CZDXYDZXDC_DXYDDCQ_2020/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300g100209_dcqtb_2020_1_latest_1_0"
                                },
                                {
                                    id: "gcs330300g100209_dcqtb_2019_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "低效调查单元图斑2020_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_1002_CZDXYDZXDC_DXYDDCDY_2020/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300g100209_dcqtb_2019_latest_1_0"
                                }
							]
						},
                        {
							layerType: "GroupLayer",
							name: "TDZYDXYDZKF",
							caption: "低效用地再开发",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300k3003_dxydzkf_xmhx_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "低效用地再开发项目红线_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_DXYDZKF_XMHX/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_dxydzkf_xmhx_latest_1_0"
                                }
							]
						},
					]
				},
                {
					layerType: "GroupLayer",
					name: "SLZY",
					caption: "森林资源",
					thematicMap: true,
					subLayers: [
                        {
                            id: "gcs330300g1099_zrbhd_2020_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "自然保护地2020_省级下发",
                            mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_1099_ZRBHD_2020/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300g1099_zrbhd_2020_latest_1_0"
                        }
					]
				},
                {
                    layerType: "GroupLayer",
					name: "CZSJ",
					caption: "地质数据",
					thematicMap: true,
					subLayers: [
                        {
                            id: "gcs330000k3005_dzyjbhq_dzgyx_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "地质遗迹保护区_省级下发",
                            mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3005_DZYJBHQ_DZGY/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330000k3005_dzyjbhq_dzgyx_latest_1_0"
                        },
                        {
                            layerType: "GroupLayer",
                            name: "DZZH",
                            caption: "地质灾害",
                            thematicMap: true,
                            subLayers:[
                                {
                                    id: "gcs330300k3005_zhyhd_yhd_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "隐患点_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3005_ZHYHD_YHD/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3005_zhyhd_yhd_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3005_zxqd_zqd_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "灾情点_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3005_ZXQD_ZQD/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3005_zxqd_zqd_x_latest_1_0"
                                },
                            ]
                        }

                    ]
                }
            ]
        },
        {
            layerType: "GroupLayer",
            name: "GHSJ",
            caption: "规划数据",
            thematicMap: true,
            subLayers: [
				{
					layerType: "GroupLayer",
					name: "ZYKZX",
					caption: "重要控制线",
					thematicMap: true,
					subLayers: [
                        {
							layerType: "GroupLayer",
							name: "ZYKZXSTBHHX",
							caption: "生态保护红线",
							thematicMap: true,
							subLayers: [{
                                    id: "gcs330300g1099_stbhhx_2018_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "生态保护红线2018_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330324_2001_STBHHX_2018/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300g1099_stbhhx_2018_latest_1_0"
                                }
							]
						},  
                        {
                            id: "gcs330300g200105_yjjbnthx_2020_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "永久基本农田保护红线2020_省级下发",
                            mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_200105_YJJBNTHX_2020/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300g200105_yjjbnthx_2020_latest_1_0"
                        }     
					]
				},
                {
					layerType: "GroupLayer",
					name: "TDLYZTGH",
					caption: "土地利用总体规划",
					thematicMap: true,
					subLayers: [
						{
                            id: "gcs330300g200201_jsydgzq_2017_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "建设用地管制区2017_省级下发",
                            mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330324_2002_TDLYGH_JSYDGZQ_2017/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300g200201_jsydgzq_2017_latest_1_0"
                        },
                        {
                            id: "gcs330300g200201_jsydgzq_2020_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "建设用地管制区2020_省级下发",
                            mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330324_2002_TDLYGH_JSYDGZQ_2020/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300g200201_jsydgzq_2020_latest_1_0"
                        },
                        {
                            id: "gcs330300k3003_ghjt_ghjbtz_x_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "规划局部调整X_省级下发",
                            mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330324_3003_GHJT_GHJBTZ/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_ghjt_ghjbtz_x_latest_1_0"
                        },
					]
				}
            ]
        },
        {
            layerType: "GroupLayer",
            name: "GLSJ",
            caption: "管理数据",
            thematicMap: true,
            subLayers:  [
				{
					layerType: "GroupLayer",
					name: "GTKJYTGZ",
					caption: "国土空间用途管制",
					thematicMap: true,
					subLayers: [
                        {
							layerType: "GroupLayer",
							name: "GTKJYTGZNZYBP",
							caption: "农转用报批",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gl_gtkjytgz_nzybp_l_gcs_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地报批（农转用地块）L_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330324_3003_JSYDBP_NZYDK_L/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gl_gtkjytgz_nzybp_l_gcs_latest_1_0"
                                },
                                {
                                    id: "gl_gtkjytgz_nzybp_x_gcs_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地报批（农转用地块）X_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330324_3003_JSYDBP_NZYDK_X/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gl_gtkjytgz_nzybp_x_gcs_latest_1_0"
                                }
							]
						},
                        {
							layerType: "GroupLayer",
							name: "GTKJYTGZJSGLXM",
							caption: "建设管理项目",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300k3003_jsydys_ysdk_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地预审（预审地块）_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/manager/instances/map-PCS330324_3003_JSYDYS_YSDK/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_jsydys_ysdk_x_latest_1_0"
                                }
                                
							]
						},
						{
							layerType: "GroupLayer",
							name: "GTKJYTGZSSNYDBA",
							caption: "设施农用地备案",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300k3003_ssnyd_bhynfw_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "补划基本农田_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_SSNYD_BHYNFW/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_ssnyd_bhynfw_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_ssnyd_gzcphjzd_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "破坏耕作层范围_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_SSNYD_GZCPHJZD/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_ssnyd_gzcphjzd_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_ssnyd_nydjzd_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "农用地范围_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_SSNYD_NYDJZD/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_ssnyd_nydjzd_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_ssnyd_phynjzd_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "破坏永农范围_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_SSNYD_PHYNJZD/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_ssnyd_phynjzd_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_ssnyd_zyynjzd_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "占用永农范围_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_SSNYD_ZYYNJZD/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_ssnyd_zyynjzd_latest_1_0"
                                },
							]
						},
                        {
							layerType: "GroupLayer",
							name: "GTKJYTGZZJGG",
							caption: "增减挂钩",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300k3003_nctdzhzz_cjdk_l_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "拆旧地块L_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_NCTDZHZZ_CJDK_L/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_nctdzhzz_cjdk_l_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_nctdzhzz_jxdk_l_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建新地块L_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_NCTDZHZZ_JXDK_L/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_nctdzhzz_jxdk_l_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_nctdzhzz_jxdk_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建新地块X_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_NCTDZHZZ_JXDK_X/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_nctdzhzz_jxdk_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdcb_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "土地储备_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDCB/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdcb_latest_1_0"
                                }
							]
						},
                        {
							layerType: "GroupLayer",
							name: "GTKJYTGZGDHX",
							caption: "供地红线",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300k3003_tdgy_gddk_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "供地地块_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDGY_GDDK/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdgy_gddk_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdgy_tdjy_zpgcr_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "土地交易-招拍挂出让地块_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDGY_TDJY_ZPGCR/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdgy_tdjy_zpgcr_latest_1_0"
                                }
							]
						},
                        {
							layerType: "GroupLayer",
							name: "GTKJYTGZTDZZ",
							caption: "土地整治",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300k3003_tdzz_gbzjs_lx_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "高标准建设地块-立项_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_GBZJS_LX/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_gbzjs_lx_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_gbzjs_ys_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "土地交易-高标准建设地块-验收_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_GBZJS_YS/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_gbzjs_ys_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_gbzts_lx_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "高标准提升地块-立项_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_GBZTS_LX/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_gbzts_lx_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_gbzts_ys_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "高标准提升地块-验收_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_GBZTS_YS/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_gbzts_ys_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_gdzlts_lx_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "耕地质量提升-立项_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_GDZLTS_LX/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_gdzlts_lx_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_gdzlts_ys_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "耕地质量提升-验收_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_GDZLTS_YS/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_gdzlts_ys_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_hgsdk_lx_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "旱改水地块-立项_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_HGSDK_LX/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_hgsdk_lx_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_hgsdk_ys_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "旱改水地块-验收_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_HGSDK_YS/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_hgsdk_ys_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_jsydfk_lx__latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地复垦地块-立项_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_JSYDFKDK_LX/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_jsydfk_lx__latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_jsydfk_ys__latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地复垦地块-验收_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_JSYDFKDK_YS/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_jsydfk_ys__latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_kzgd_lx_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "垦造耕地-立项_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_KZGDDK_LX/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_kzgd_lx_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3003_tdzz_kzgd_ys_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "垦造耕地-验收_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3003_TDZZ_KZGDDK_YS/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3003_tdzz_kzgd_ys_x_latest_1_0"
                                }
							]
						},
					]
				},
                {
                    layerType: "GroupLayer",
					name: "KCGL",
					caption: "矿产管理",
					thematicMap: true,
                    subLayers:[
                        {
							layerType: "GroupLayer",
							name: "KCGLCKQ",
							caption: "采矿权",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300k3004_ckq_ckqdj_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "采矿权登记_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_CKQ_CKQDJ/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_ckq_ckqdj_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3004_ckq_hdkqfw_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "划定矿区范围_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_CKQ_HDKQFW/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_ckq_hdkqfw_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3004_ckqdj_lsx_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "采矿权登记-历史_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_CKQ_CKQDJ_LS/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_ckqdj_lsx_latest_1_0"
                                }
							]
						},
                        {
							layerType: "GroupLayer",
							name: "KCGLCLDJ",
							caption: "储量登记",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300k3004_cldj_cmdj_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "查明登记_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_CLDJ_GT_ZYCM/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_cldj_cmdj_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3004_cldj_drkqs_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "地热矿泉水登记_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_CLDJ_DRKQSDJ/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_cldj_drkqs_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3004_cldj_jsydyf_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地压覆_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_CLDJ_JSYDYF/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_cldj_jsydyf_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3004_cldj_yfdj_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "压覆登记_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_CLDJ_GT_ZYYF/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_cldj_yfdj_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3004_cldj_zydj_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "占用登记_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_CLDJ_GT_ZYZY/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_cldj_zydj_x_latest_1_0"
                                }
							]
						},
                        {
                            id: "gcs330300k3004_fqks_fqks_x_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "废弃矿山_省级下发",
                            mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_FQKS_FQKSZXD/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_fqks_fqks_x_latest_1_0"
                        },
                        {
                            id: "gcs330300k3004_lsks_lsks_x_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "绿色矿山_省级下发",
                            mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_LSKS_LSKS/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_lsks_lsks_x_latest_1_0"
                        },
                        {
                            layerType: "GroupLayer",
							name: "KCGLCKQ",
							caption: "采矿权",
							thematicMap: true,
                            subLayers: [
                                {
                                    id: "gcs330300k3004_tkq_dzdc_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "探矿权地质调查_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_TKQ_DZDC/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_tkq_dzdc_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3004_tkq_kcdj_lsx_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "探矿权勘查登记_历史_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_TKQ_KCDJ_LS/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_tkq_kcdj_lsx_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3004_tkq_kcdj_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "探矿权勘查登记_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3004_TKQ_KCDJ/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_tkq_kcdj_x_latest_1_0"
                                },
                            ]
                        }
                    ]
                },
                {
                    layerType: "GroupLayer",
					name: "PHJG",
					caption: "批后监管",
					thematicMap: true,
                    subLayers:[
                        {
							layerType: "GroupLayer",
							name: "PHGLWTZZ",
							caption: "问题整治",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330000k3099_wtzz_dpfwtzzx_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "大棚房问题整治_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3099_WTZZ_DPFWTZZ/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3004_ckq_ckqdj_x_latest_1_0"
                                },
                                {
                                    id: "gcs330300k3099_wtzz_ssnydzzx_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "设施农用地整治_省级下发",
                                    mapUrl: "http://10.36.128.57:8090/iserver/services/map-PCS330324_3099_WTZZ_SSNYDZZ/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.57:8090/iserver/services/data-h_yongjia/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_yongjia:gcs330300k3099_wtzz_ssnydzzx_latest_1_0"
                                }
							]
						},
                    ]
                }
               
            ]
        }
    ]

});
