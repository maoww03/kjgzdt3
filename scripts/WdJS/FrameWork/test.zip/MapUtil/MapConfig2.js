define({
    option: {
        view: {
            center: [567813.634, 3096556.623],
            zoom: 3
            //maxZoom: 15,
            //minZoom: 6
        }
    },
    extent: [423788.27389814425, 2935769.3486772366, 719810.8880697023, 3188104.0327783935],
    resolutions: [
        156367.79197931726,
        78183.89598965863,
        39091.947994829316,
        19545.973997414658,
        9772.986998707329,
        4886.493499353664,
        2443.246749676832,
        1221.623374838416,
        610.811687419208,
        305.405843709604,
        152.702921854802,
        76.351460927401,
        38.1757304637005,
        19.08786523185025,
        9.543932615925126,
        4.771966307962563,
        2.3859831539812815,
        1.1929915769906407,
        0.5964957884953204,
        0.2982478942476602,
        0.1491239471238301
    ],
    layers: [
        {
            layerType: "GroupLayer",
            name: "VectorMap",
            caption: "矢量地图",
            baseMap: true,
            logo: "image/tiledVector.png",
            opacity: 0.5,
            visible: true,
            subLayers: [
            {
                id: "WZVectorMap",
                layerType: "ArcgisWMTS",
                caption: "温州矢量地图",
                origin: [-5123200.0, 1.00021E7],
                mapUrl: "http://10.36.128.241:10901/api/esb/esbdataservice/findService/wmts/7d54c9c59c3024eb03fa59cc69ab10c1",
                //url: "http://localhost/arcgisrest/Tile/GCS330300_1002_TDLYXZ_2018_GCS330300_1002_TDLYXZ_DLTB_2018/MapServer/tile/{z}/{y}/{x}",
                visible: true,
                opacity: 1
            }
                
            ]
        }
        
       
    ]

});
