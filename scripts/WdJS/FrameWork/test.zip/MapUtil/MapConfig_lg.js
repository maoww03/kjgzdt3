define({
    code:"1",
    option: {
        view: {
            center: [567813.634, 3096556.623],
            zoom: 3
            //maxZoom: 15,
            //minZoom: 6
        }
    },
    extent: [423788.27389814425, 2935769.3486772366, 719810.8880697023, 3188104.032778393],
    resolutions: [  
        156367.79197931726,
        78183.89598965863,
        39091.947994829316,
        19545.973997414658,
        9772.986998707329,
        4886.493499353664,
        2443.246749676832,
        1221.623374838416,
        610.811687419208,
        305.405843709604,
        152.702921854802,
        76.351460927401,
        38.1757304637005,
        19.08786523185025,
        9.543932615925126,
        4.771966307962563,
        2.3859831539812815,
        1.1929915769906407,
        0.5964957884953204,
        0.2982478942476602,
        0.1491239471238301
    ],
    layers: [
        {
            layerType: "GroupLayer",
            name: "XZSJ",
            caption: "现状数据",
            thematicMap: true,
            subLayers:[
				{
					layerType: "GroupLayer",
					name: "TDZY",
					caption: "土地资源",
					thematicMap: true,
					subLayers: [
						{
							layerType: "GroupLayer",
							name: "TDZYDXYDZXDC",
							caption: "低效用地专项调查",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300g100209_dcqtb_2019_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "低效调查区图斑2019_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330383_1002_CZDXYDZXDC_DXYDDCQ_2019/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_longgang/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_longgang:gcs330300g100209_dcqtb_2019_latest_1_0"
                                },
                                {
                                    id: "gcs330300g100209_dcqtb_2020_1_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "低效调查区图斑2020_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330383_1002_CZDXYDZXDC_DXYDDCQ_2020/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_longgang/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_longgang:gcs330300g100209_dcqtb_2020_1_latest_1_0"
                                }
							]
						},
					]
				}
            ]
        },
        {
            layerType: "GroupLayer",
            name: "GHSJ",
            caption: "规划数据",
            thematicMap: true,
            subLayers: [
				{
					layerType: "GroupLayer",
					name: "ZYKZX",
					caption: "重要控制线",
					thematicMap: true,
					subLayers: [
						{
							layerType: "GroupLayer",
							name: "ZYKZXSTBHHX",
							caption: "生态保护红线",
							thematicMap: true,
							subLayers: [{
                                    id: "gcs330300g1099_stbhhx_2018_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "生态保护红线2018_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330383_2001_STBHHX_2018/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_longgang/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_longgang:gcs330300g1099_stbhhx_2018_latest_1_0"
                                }
							]
						},
					]
				},
                {
					layerType: "GroupLayer",
					name: "ZYKZX",
					caption: "土地利用总体规划",
					thematicMap: true,
					subLayers: [
						{
                            id: "gcs330300g200201_jsydgzq_2017_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "建设用地管制区2017_省级下发",
                            mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330383_2002_TDLYGH_JSYDGZQ_2017/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_longgang/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_longgang:gcs330300g200201_jsydgzq_2017_latest_1_0"
                        },
                        {
                            id: "gcs330300g200201_jsydgzq_2020_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "建设用地管制区2020_省级下发",
                            mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330383_2002_TDLYGH_JSYDGZQ_2020/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_longgang/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_longgang:gcs330300g200201_jsydgzq_2020_latest_1_0"
                        },
                        {
                            id: "gcs330300k3003_ghjt_ghjbtz_x_latest_1_0",
                            layerType: "SuperMapWMTS",
                            caption: "规划局部调整X_省级下发",
                            mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330383_3003_GHJT_GHJBTZ/wmts100",
                            visible: false,
                            queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_longgang/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_longgang:gcs330300k3003_ghjt_ghjbtz_x_latest_1_0"
                        },
					]
				}
            ]
        },
        {
            layerType: "GroupLayer",
            name: "GLSJ",
            caption: "管理数据",
            thematicMap: true,
            subLayers:  [
				{
					layerType: "GroupLayer",
					name: "ZYKZX",
					caption: "国土空间用途管制",
					thematicMap: true,
					subLayers: [
						{
							layerType: "GroupLayer",
							name: "ZYKZXSTBHHX",
							caption: "农转用报批",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gl_gtkjytgz_nzybp_l_gcs_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地报批（农转用地块）L_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330383_3003_JSYDBP_NZYDK_L/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_longgang/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_longgang:gl_gtkjytgz_nzybp_l_gcs_latest_1_0"
                                },
                                {
                                    id: "gl_gtkjytgz_nzybp_x_gcs_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地报批（农转用地块）X_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330383_3003_JSYDBP_NZYDK_X-2/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_longgang/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_longgang:gl_gtkjytgz_nzybp_x_gcs_latest_1_0"
                                }
							]
						},
                        {
							layerType: "GroupLayer",
							name: "ZYKZXSTBHHX",
							caption: "建设管理项目",
							thematicMap: true,
							subLayers: [
                                {
                                    id: "gcs330300k3003_jsydys_ysdk_x_latest_1_0",
                                    layerType: "SuperMapWMTS",
                                    caption: "建设用地预审（预审地块）_省级下发",
                                    mapUrl: "http://10.36.128.241:28090/iserver/services/map-PCS330383_3003_JSYDYS_YSDK/wmts100",
                                    visible: false,
                                    queryUrl: "http://10.36.128.241:28090/iserver/services/data-h_longgang/wfs100/utf-8?service=wfs&version=1.1.0&request=GetFeature&TYPENAME=h_longgang:gcs330300k3003_jsydys_ysdk_x_latest_1_0"
                                }
                                
							]
						},
					]
				},
               
            ]
        }
    ]

});
